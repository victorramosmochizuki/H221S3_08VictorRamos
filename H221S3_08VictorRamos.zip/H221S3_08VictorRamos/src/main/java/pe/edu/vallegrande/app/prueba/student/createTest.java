package pe.edu.vallegrande.app.prueba.student;

import pe.edu.vallegrande.app.model.Student;
import pe.edu.vallegrande.app.service.CrudStudentService;

public class createTest {
    public static void main(String[] args) {
        // Crear una instancia de Student
        Student student = new Student();
        student.setNames("John");
        student.setSurname("Doe");
        student.setDocument_type("DNI");
        student.setDocument_number("12345678");
        //student.setDegree_section("1A");
        student.setCarrera("ANALISIS DE SISTEMAS");
        student.setCiclo("1");
        student.setCellphone("987654321");
        student.setEmail("john.doe@example.com");
        student.setFather_document("john.123654987.com");
        student.setMother_document("123654987");

        // Crear una instancia de CrudStudentService
        CrudStudentService studentService = new CrudStudentService();

        // Llamar al método create() para crear el estudiante
        studentService.create(student);
    }
}
