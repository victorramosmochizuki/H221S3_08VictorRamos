package pe.edu.vallegrande.app.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import pe.edu.vallegrande.app.db.AccesoDB;
import pe.edu.vallegrande.app.model.Attorney;
import pe.edu.vallegrande.app.service.spec.CrudServiceSpec;
import pe.edu.vallegrande.app.service.spec.RowMapper;

public class CrudAttorneyService implements CrudServiceSpec<Attorney>, RowMapper<Attorney> {

	// Definiendo consultas
	private final String SQL_SELECT_BASE = "SELECT attorney_id, names, surname, document_type, document_number, cellphone, email, states FROM ATTORNEY";
	private final String SQL_CREATE = "INSERT INTO ATTORNEY (names, surname, document_type, document_number, cellphone, email) VALUES (?, ?, ?, ?, ?, ?)";
	private final String SQL_UPDATE = "UPDATE ATTORNEY SET names=?, surname=?, document_type=?, document_number=?, cellphone=?, email=? WHERE attorney_id=?";
	private final String SQL_STATES = "UPDATE ATTORNEY SET states=? WHERE attorney_id=?";

	// Mapeado de listas
	@Override
	public Attorney mapRow(ResultSet rs) throws SQLException {
		Attorney bean = new Attorney();

		bean.setAttorney_id(rs.getInt("attorney_id"));
		bean.setNames(rs.getString("names"));
		bean.setSurname(rs.getString("surname"));
		bean.setDocument_type(rs.getString("document_type"));
		bean.setDocument_number(rs.getString("document_number"));
		bean.setCellphone(rs.getString("cellphone"));
		bean.setEmail(rs.getString("email"));
		bean.setStates(rs.getString("states"));

		return bean;
	}

	// Creación de registros
	@Override
	public void create(Attorney bean) {
	    try (Connection conn = AccesoDB.getConnection();
	            PreparedStatement pstmt = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {

	        pstmt.setString(1, bean.getNames());
	        pstmt.setString(2, bean.getSurname());
	        pstmt.setString(3, bean.getDocument_type());
	        pstmt.setString(4, bean.getDocument_number());
	        pstmt.setString(5, bean.getCellphone());
	        pstmt.setString(6, bean.getEmail());

	        int rowsAffected = pstmt.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Número de Documento: " + bean.getDocument_number());
	            System.out.println("Registro insertado: " + bean);
	        } else {
	            System.out.println("Error al crear el registro");
	        }

	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	// Reactivacion de registros
	@Override
	public void reactivate(int id) {
		try (Connection conn = AccesoDB.getConnection(); PreparedStatement pstmt = conn.prepareStatement(SQL_STATES)) {

			pstmt.setString(1, "A");
			pstmt.setInt(2, id);

			int rowsAffected = pstmt.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Apoderado reactivado con ID: " + id);
			} else {
				System.out.println("No se encontró ningún abogado con el ID proporcionado: " + id);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Actualizar de registros
	@Override
	public void update(Attorney bean) {
		try (Connection conn = AccesoDB.getConnection(); PreparedStatement pstmt = conn.prepareStatement(SQL_UPDATE)) {

			pstmt.setString(1, bean.getNames());
			pstmt.setString(2, bean.getSurname());
			pstmt.setString(3, bean.getDocument_type());
			pstmt.setString(4, bean.getDocument_number());
			pstmt.setString(5, bean.getCellphone());
			pstmt.setString(6, bean.getEmail());
			pstmt.setInt(7, bean.getAttorney_id());

			int rowsAffected = pstmt.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Apoderado actualizado con ID: " + bean.getAttorney_id());
			} else {
				System.out.println("No se encontró ningún abogado con el ID proporcionado: " + bean.getAttorney_id());
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Eliminado logico
	@Override
	public void softDelete(int id) {
		try (Connection conn = AccesoDB.getConnection(); PreparedStatement pstmt = conn.prepareStatement(SQL_STATES)) {

			pstmt.setString(1, "I");
			pstmt.setInt(2, id);

			int rowsAffected = pstmt.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Apoderado eliminado suavemente con ID: " + id);
			} else {
				System.out.println("No se encontró ningún apoderado con el ID proporcionado: " + id);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	// Mostrar todo
	@Override
	public List<Attorney> getAll() {
		List<Attorney> attorneys = new ArrayList<>();

		try (Connection conn = AccesoDB.getConnection();
				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(SQL_SELECT_BASE)) {

			while (rs.next()) {
				int attorneyId = rs.getInt("attorney_id");
				String names = rs.getString("names");
				String surname = rs.getString("surname");
				String documentType = rs.getString("document_type");
				String documentNumber = rs.getString("document_number");
				String cellphone = rs.getString("cellphone");
				String email = rs.getString("email");
				String states = rs.getString("states");

				Attorney attorney = new Attorney(attorneyId, names, surname, documentType, documentNumber, cellphone,
						email, states);

				attorneys.add(attorney);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return attorneys;
	}

	// Buscar por id
	@Override
	public Attorney getById(int id) {
		Attorney attorney = null;

		try (Connection conn = AccesoDB.getConnection();
				PreparedStatement stmt = conn.prepareStatement(SQL_SELECT_BASE + " WHERE attorney_id = ?")) {

			stmt.setInt(1, id);
			ResultSet rs = stmt.executeQuery();

			if (rs.next()) {
				int attorneyId = rs.getInt("attorney_id");
				String names = rs.getString("names");
				String surname = rs.getString("surname");
				String documentType = rs.getString("document_type");
				String documentNumber = rs.getString("document_number");
				String cellphone = rs.getString("cellphone");
				String email = rs.getString("email");
				String states = rs.getString("states");

				attorney = new Attorney(attorneyId, names, surname, documentType, documentNumber, cellphone, email,
						states);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return attorney;
	}
	
	// Buscar por filtros
	@Override
	public List<Attorney> getFilters(Attorney bean) {
		// Variables
		Connection cn = null;
		List<Attorney> lista = new ArrayList<>();
		PreparedStatement pstm = null;
		ResultSet rs = null;
		Attorney item;
		String sql;
		String names;
		String surname;
		String document_number;
		String states;
		// Preparar los datos
		names = "%" + UtilService.setStringVacio(bean.getNames()) + "%";
		surname = "%" + UtilService.setStringVacio(bean.getSurname()) + "%";
		document_number = "%" + UtilService.setStringVacio(bean.getDocument_number()) + "%";
		states = "%" + UtilService.setStringVacio(bean.getStates()) + "%";
		// Proceso
		try {
			// Conexion
			cn = AccesoDB.getConnection();
			// La consulta
			sql = SQL_SELECT_BASE + " WHERE names LIKE ? AND surname LIKE ? AND document_number LIKE ? AND states LIKE ?";
			pstm = cn.prepareStatement(sql);
			pstm.setString(1, names);
			pstm.setString(2, surname);
			pstm.setString(3, document_number);
			pstm.setString(4, states);
			rs = pstm.executeQuery();
			while (rs.next()) {
				item = mapRow(rs);
				lista.add(item);
			}
			rs.close();
			pstm.close();
		} catch (SQLException e) {
			throw new RuntimeException(e.getMessage());
		} finally {
			try {
				cn.close();
			} catch (Exception e2) {
			}
		}
		return lista;
	}
}
