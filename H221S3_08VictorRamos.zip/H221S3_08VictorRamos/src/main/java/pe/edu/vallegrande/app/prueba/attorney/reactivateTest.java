package pe.edu.vallegrande.app.prueba.attorney;

import pe.edu.vallegrande.app.service.CrudAttorneyService;

public class reactivateTest {
    public static void main(String[] args) {
        // ID del abogado a reactivar
        int attorneyId = 1; // Reemplaza con el ID del abogado que deseas reactivar
        
        // Crear una instancia de CrudAttorneyService
        CrudAttorneyService attorneyService = new CrudAttorneyService();
        
        // Llamar al método reactivate para reactivar al abogado
        attorneyService.reactivate(attorneyId);
    }
}
