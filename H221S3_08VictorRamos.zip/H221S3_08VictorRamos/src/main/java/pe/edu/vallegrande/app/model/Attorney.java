package pe.edu.vallegrande.app.model;

public class Attorney {

    private int attorney_id;
    private String names;
    private String surname;
    private String document_type;
    private String document_number;
    private String cellphone;
    private String email;
    private String states;

    public Attorney() {
    }

    public Attorney(int attorney_id, String names, String surname, String document_type, String document_number,
                    String cellphone, String email, String states) {
        this.attorney_id = attorney_id;
        this.names = names;
        this.surname = surname;
        this.document_type = document_type;
        this.document_number = document_number;
        this.cellphone = cellphone;
        this.email = email;
        this.states = states;
    }

    public int getAttorney_id() {
        return attorney_id;
    }

    public void setAttorney_id(int attorney_id) {
        this.attorney_id = attorney_id;
    }

    public String getNames() {
        return names;
    }

    public void setNames(String names) {
        this.names = names;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getDocument_type() {
        return document_type;
    }

    public void setDocument_type(String document_type) {
        this.document_type = document_type;
    }

    public String getDocument_number() {
        return document_number;
    }

    public void setDocument_number(String document_number) {
        this.document_number = document_number;
    }

    public String getCellphone() {
        return cellphone;
    }

    public void setCellphone(String cellphone) {
        this.cellphone = cellphone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getStates() {
        return states;
    }

    public void setStates(String states) {
        this.states = states;
    }

    @Override
    public String toString() {
        String data = "[attorney_id: " + this.attorney_id;
        data += ", names: " + this.names;
        data += ", surname: " + this.surname;
        data += ", document_type: " + this.document_type;
        data += ", document_number: " + this.document_number;
        data += ", cellphone: " + this.cellphone;
        data += ", email: " + this.email;
        data += ", states: " + this.states;

        return data;
    }
}
