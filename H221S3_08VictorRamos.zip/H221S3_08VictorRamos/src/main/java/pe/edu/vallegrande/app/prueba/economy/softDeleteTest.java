package pe.edu.vallegrande.app.prueba.economy;

import pe.edu.vallegrande.app.service.CrudEconomyService;

public class softDeleteTest {
    public static void main(String[] args) {
        // ID del abogado a eliminar
        int economy_id = 2; // Reemplaza con el ID del abogado que deseas eliminar
        
        // Crear una instancia de CrudAttorneyService
        CrudEconomyService attorneyService = new CrudEconomyService();
        
        // Llamar al método softDelete para eliminar suavemente al abogado
        attorneyService.softDelete(economy_id);
    }
}
