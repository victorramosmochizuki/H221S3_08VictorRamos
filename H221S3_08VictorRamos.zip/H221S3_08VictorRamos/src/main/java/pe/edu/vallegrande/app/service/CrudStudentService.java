package pe.edu.vallegrande.app.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import pe.edu.vallegrande.app.db.AccesoDB;
import pe.edu.vallegrande.app.model.Student;
import pe.edu.vallegrande.app.service.spec.CrudServiceSpec;
import pe.edu.vallegrande.app.service.spec.RowMapper;

public class CrudStudentService implements CrudServiceSpec<Student>, RowMapper<Student> {

	// Definiendo consultas
	private final String SQL_SELECT_BASE = "SELECT student_id, names, surname, document_type, document_number, carrera, ciclo, cellphone, email, father_document, mother_document, states FROM STUDENT";
	private final String SQL_CREATE = "INSERT INTO STUDENT(names, surname, document_type, document_number, carrera, ciclo cellphone, email, father_document, mother_document) VALUES( ?, ?, ?, ?, ?, ?, ?, ?,?, ?)";
	private final String SQL_UPDATE = "UPDATE STUDENT SET names=?, surname=?, document_type=?, document_number=?, carrera=?, ciclo=?, cellphone=?, email=? WHERE student_id=?";
	private final String SQL_STATES = "UPDATE STUDENT SET states=? WHERE student_id=?";

	// Mapeado de listas
	@Override
	public Student mapRow(ResultSet rs) throws SQLException {
		Student bean = new Student();

		bean.setStudent_id(rs.getInt("student_id"));
		bean.setNames(rs.getString("names"));
		bean.setSurname(rs.getString("surname"));
		bean.setDocument_type(rs.getString("document_type"));
		bean.setDocument_number(rs.getString("document_number"));
		bean.setCarrera(rs.getString("carrera"));
		bean.setCiclo(rs.getString("ciclo"));
		bean.setCellphone(rs.getString("cellphone"));
		bean.setEmail(rs.getString("email"));
		bean.setFather_document(rs.getString("father_document"));
		bean.setMother_document(rs.getString("mother_document"));
		bean.setStates(rs.getString("states"));

		return bean;
	}

	// Creación de registros
	@Override
	public void create(Student bean) {
		try (Connection conn = AccesoDB.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {

			pstmt.setString(1, bean.getNames());
			pstmt.setString(2, bean.getSurname());
			pstmt.setString(3, bean.getDocument_type());
			pstmt.setString(4, bean.getDocument_number());
			//pstmt.setString(5, bean.getDegree_section());
			pstmt.setString(5, bean.getCarrera());
			pstmt.setString(5, bean.getCiclo());
			pstmt.setString(6, bean.getCellphone());
			pstmt.setString(7, bean.getEmail());
			pstmt.setString(8, bean.getFather_document());
			pstmt.setString(9, bean.getMother_document());

			int rowsAffected = pstmt.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Número de Documento: " + bean.getDocument_number());
				System.out.println("Registro insertado: " + bean);
			} else {
				System.out.println("Error al crear el registro");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Reactivacion de registros
	@Override
	public void reactivate(int id) {
		try (Connection conn = AccesoDB.getConnection(); PreparedStatement pstmt = conn.prepareStatement(SQL_STATES)) {

			pstmt.setString(1, "A");
			pstmt.setInt(2, id);

			int rowsAffected = pstmt.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Estudiante reactivado con ID: " + id);
			} else {
				System.out.println("No se encontró ningún estudiante con el ID proporcionado: " + id);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Actualizar de registros
	@Override
	public void update(Student bean) {
		try (Connection conn = AccesoDB.getConnection(); PreparedStatement pstmt = conn.prepareStatement(SQL_UPDATE)) {

			pstmt.setString(1, bean.getNames());
			pstmt.setString(2, bean.getSurname());
			pstmt.setString(3, bean.getDocument_type());
			pstmt.setString(4, bean.getDocument_number());
			//pstmt.setString(5, bean.getDegree_section());
			pstmt.setString(5, bean.getCarrera());
			pstmt.setString(5, bean.getCiclo());
			pstmt.setString(6, bean.getCellphone());
			pstmt.setString(7, bean.getEmail());
			pstmt.setInt(8, bean.getStudent_id());

			int rowsAffected = pstmt.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Apoderado actualizado con ID: " + bean.getStudent_id());
			} else {
				System.out.println("No se encontró ningún abogado con el ID proporcionado: " + bean.getStudent_id());
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Eliminado logico
	@Override
	public void softDelete(int id) {
		try (Connection conn = AccesoDB.getConnection(); PreparedStatement pstmt = conn.prepareStatement(SQL_STATES)) {

			pstmt.setString(1, "I");
			pstmt.setInt(2, id);

			int rowsAffected = pstmt.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Estudiante eliminado suavemente con ID: " + id);
			} else {
				System.out.println("No se encontró ningún estudiante con el ID proporcionado: " + id);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Mostrar todo
	@Override
	public List<Student> getAll() {
	    List<Student> students = new ArrayList<>();

	    try (Connection conn = AccesoDB.getConnection();
	         Statement stmt = conn.createStatement();
	         ResultSet rs = stmt.executeQuery(SQL_SELECT_BASE)) {

	        while (rs.next()) {
	            int studentId = rs.getInt("student_id");
	            String names = rs.getString("names");
	            String surname = rs.getString("surname");
	            String documentType = rs.getString("document_type");
	            String documentNumber = rs.getString("document_number");
	            //String degreeSection = rs.getString("degree_section");
	            String carrera = rs.getString("carrera");
	            String ciclo = rs.getString("ciclo");
	            String cellphone = rs.getString("cellphone");
	            String email = rs.getString("email");
	            String fatherDocument = rs.getString("father_document");
	            String motherDocument = rs.getString("mother_document");
	            String states = rs.getString("states");

	            Student student = new Student(studentId, names, surname, documentType, documentNumber, carrera, ciclo, cellphone,
	                    email, fatherDocument, motherDocument, states);

	            students.add(student);
	        }

	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return students;
	}

	// Buscar por id
	@Override
	public Student getById(int id) {
	    Student student = null;

	    try (Connection conn = AccesoDB.getConnection();
	         PreparedStatement stmt = conn.prepareStatement(SQL_SELECT_BASE + " WHERE student_id = ?")) {

	        stmt.setInt(1, id);
	        ResultSet rs = stmt.executeQuery();

	        if (rs.next()) {
	            int studentId = rs.getInt("student_id");
	            String names = rs.getString("names");
	            String surname = rs.getString("surname");
	            String documentType = rs.getString("document_type");
	            String documentNumber = rs.getString("document_number");
	            //String degreeSection = rs.getString("degree_section");
	            String carrera = rs.getString("carrera");
	            String ciclo = rs.getString("ciclo");
	            String cellphone = rs.getString("cellphone");
	            String email = rs.getString("email");
	            String fatherDocument = rs.getString("father_document");
	            String motherDocument = rs.getString("mother_document");
	            String states = rs.getString("states");

	            student = new Student(studentId, names, surname, documentType, documentNumber, carrera, ciclo, cellphone,
	                    email, fatherDocument, motherDocument, states);
	        }

	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return student;
	}

	// Buscar por filtros
	@Override
	public List<Student> getFilters(Student bean) {
		// Variables
		Connection cn = null;
		List<Student> lista = new ArrayList<>();
		PreparedStatement pstm = null;
		ResultSet rs = null;
		Student item;
		String sql;
		String names;
		String surname;
		String document_number;
		//String degree_section;
		String carrera;
		String ciclo;
		String states;
		// Preparar los datos
		names = "%" + UtilService.setStringVacio(bean.getNames()) + "%";
		surname = "%" + UtilService.setStringVacio(bean.getSurname()) + "%";
		document_number = "%" + UtilService.setStringVacio(bean.getDocument_number()) + "%";
		//degree_section = "%" + UtilService.setStringVacio(bean.getDegree_section()) + "%";
		carrera = "%" + UtilService.setStringVacio(bean.getCarrera()) + "%";
		ciclo = "%" + UtilService.setStringVacio(bean.getCiclo()) + "%";
		states = "%" + UtilService.setStringVacio(bean.getStates()) + "%";
		// Proceso
		try {
			// Conexion
			cn = AccesoDB.getConnection();
			// La consulta
			sql = SQL_SELECT_BASE + " WHERE names LIKE ? AND surname LIKE ? AND document_number LIKE ? AND carrera LIKE ? AND ciclo LIKE ? AND states LIKE ?";
			pstm = cn.prepareStatement(sql);
			pstm.setString(1, names);
			pstm.setString(2, surname);
			pstm.setString(3, document_number);
			//pstm.setString(4, degree_section);
			pstm.setString(4, carrera);
			pstm.setString(5, ciclo);
			pstm.setString(6, states);
			rs = pstm.executeQuery();
			while (rs.next()) {
				item = mapRow(rs);
				lista.add(item);
			}
			rs.close();
			pstm.close();
		} catch (SQLException e) {
			throw new RuntimeException(e.getMessage());
		} finally {
			try {
				cn.close();
			} catch (Exception e2) {
			}
		}
		return lista;
	}
}
