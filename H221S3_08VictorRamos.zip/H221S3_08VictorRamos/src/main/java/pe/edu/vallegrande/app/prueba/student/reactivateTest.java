package pe.edu.vallegrande.app.prueba.student;

import pe.edu.vallegrande.app.service.CrudStudentService;

public class reactivateTest {
    public static void main(String[] args) {
        // ID del abogado a reactivar
        int student_id = 1; // Reemplaza con el ID del abogado que deseas reactivar
        
        // Crear una instancia de CrudAttorneyService
        CrudStudentService studentService = new CrudStudentService();
        
        // Llamar al método reactivate para reactivar al abogado
        studentService.reactivate(student_id);
    }
}
