package pe.edu.vallegrande.app.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.google.gson.Gson;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import pe.edu.vallegrande.app.model.Economy;
import pe.edu.vallegrande.app.service.CrudEconomyService;

@WebServlet({ "/EconomyBuscar", "/EconomyBuscar2", "/EconomyProcesar", "/EconomyDescargar" })
public class EconomyController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private CrudEconomyService service = new CrudEconomyService();

	// Metodos URL
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = request.getServletPath();
		switch (path) {
		case "/EconomyBuscar":
			EconomyBuscar(request, response);
			break;
		case "/EconomyBuscar2":
			EconomyBuscar2(request, response);
			break;
		case "/EconomyProcesar":
			EconomyProcesar(request, response);
			break;
		case "/EconomyDescargar":
			EconomyDescargar(request, response);
			break;
		}
	}

	private void EconomyDescargar(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String type = request.getParameter("type");

		List<Economy> lista = service.getFilters(new Economy());

		if ("excel".equals(type)) {
			generateExcel(lista, response);
			String filePath = "economy.xlsx";
			downloadFile(filePath, response);
		} else if ("pdf".equals(type)) {
			generatePDF(lista, response);
			String filePath = "economy.pdf";
			downloadFile(filePath, response);
		} else if ("csv".equals(type)) {
			generateCSV(lista, response);
			String filePath = "economy.csv";
			downloadFile(filePath, response);
		} else {
			response.getWriter().write("Tipo de archivo inválido");
		}
	}

	private void generateCSV(List<Economy> lista, HttpServletResponse response) {
		// Obtener el directorio de inicio del usuario
		String userHome = System.getProperty("user.home");

		// Definir el nombre del archivo
		String fileName = "economies.csv";

		// Obtener la ruta completa de la carpeta de descargas
		String downloadsPath = "";
		if (System.getProperty("os.name").toLowerCase().contains("win")) {
			// Windows
			downloadsPath = userHome + "\\Downloads";
		} else if (System.getProperty("os.name").toLowerCase().contains("mac")) {
			// Mac
			downloadsPath = userHome + "/Downloads";
		}

		// Crear la ruta completa del archivo
		Path file = FileSystems.getDefault().getPath(downloadsPath, fileName);

		response.setContentType("text/csv");
		response.setHeader("Content-Disposition", "attachment; filename=" + fileName);

		try (PrintWriter writer = response.getWriter()) {
			// Escribir encabezados de columna
			writer.println(
					"ID de la Economia,Modalidad,Tipo de Economia,Numero de Operacion,Tipo de Persona,Tipo de Documento,Numero de Documento,Descripciones,Monto,Ingresos Totales,Gastos Totales,Diferencias,Estado,Fecha y Hora");

			// Escribir datos de las economías
			for (Economy economy : lista) {
				writer.print(economy.getEconomy_id() + ",");
				writer.print(economy.getModality() + ",");
				writer.print(economy.getEconomy_type() + ",");
				writer.print(economy.getNumber_operation() + ",");
				writer.print(economy.getPerson_type() + ",");
				writer.print(economy.getDocument_type() + ",");
				writer.print(economy.getDocument_number() + ",");
				writer.print(economy.getDescriptions() + ",");
				writer.print(economy.getAmount() + ",");
				writer.print(economy.getTotal_incomes() + ",");
				writer.print(economy.getTotal_expenses() + ",");
				writer.print(economy.getDiferencity() + ",");
				writer.print(economy.getStates() + ",");
				writer.println(economy.getDate_hour());
			}

			System.out.println("Archivo CSV generado exitosamente en: " + file.toString());
		} catch (IOException e) {
			System.out.println("Error al generar el archivo CSV: " + e.getMessage());
		}
	}

	private void generatePDF(List<Economy> lista, HttpServletResponse response) {
		String userHome = System.getProperty("user.home");
		String fileName = "economies.pdf";
		String downloadsPath = "";

		if (System.getProperty("os.name").toLowerCase().contains("win")) {
			// Windows
			downloadsPath = userHome + "\\Downloads";
		} else if (System.getProperty("os.name").toLowerCase().contains("mac")) {
			// Mac
			downloadsPath = userHome + "/Downloads";
		}

		Path file = FileSystems.getDefault().getPath(downloadsPath, fileName);

		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment; filename=" + fileName);

		try (OutputStream outputStream = response.getOutputStream()) {
			Document document = new Document();
			document.setPageSize(PageSize.A4.rotate()); // Configurar orientación apaisada
			PdfWriter.getInstance(document, outputStream);
			document.open();

			// Crear la tabla con 14 columnas
			PdfPTable table = new PdfPTable(14);

			// Ajustar el ancho de la tabla
			table.setTotalWidth(document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin());

			// Añadir los encabezados de columna a la tabla
			table.addCell("ID de la Economía");
			table.addCell("Modalidad");
			table.addCell("Tipo de Economía");
			table.addCell("Número de Operación");
			table.addCell("Tipo de Persona");
			table.addCell("Tipo de Documento");
			table.addCell("Número de Documento");
			table.addCell("Descripciones");
			table.addCell("Monto");
			table.addCell("Ingresos Totales");
			table.addCell("Gastos Totales");
			table.addCell("Diferencias");
			table.addCell("Estado");
			table.addCell("Fecha y Hora");

			// Añadir los datos de las economías a la tabla
			for (Economy economy : lista) {
				table.addCell(String.valueOf(economy.getEconomy_id()));
				table.addCell(economy.getModality());
				table.addCell(economy.getEconomy_type());
				table.addCell(economy.getNumber_operation());
				table.addCell(economy.getPerson_type());
				table.addCell(economy.getDocument_type());
				table.addCell(economy.getDocument_number());
				table.addCell(economy.getDescriptions());
				table.addCell(String.valueOf(economy.getAmount().doubleValue()));
				table.addCell(String.valueOf(economy.getTotal_incomes().doubleValue()));
				table.addCell(String.valueOf(economy.getTotal_expenses().doubleValue()));
				table.addCell(String.valueOf(economy.getDiferencity().doubleValue()));
				table.addCell(economy.getStates());
				table.addCell(economy.getDate_hour().toString());
			}

			// Añadir la tabla al documento
			document.add(table);

			document.close();
			System.out.println("Archivo PDF generado exitosamente en: " + file.toString());
		} catch (DocumentException e) {
			System.out.println("Error al generar el archivo PDF: " + e.getMessage());
		} catch (IOException e) {
			System.out.println("Error al escribir en el OutputStream: " + e.getMessage());
		}
	}

	private void generateExcel(List<Economy> lista, HttpServletResponse response) {
		String userHome = System.getProperty("user.home");
		String fileName = "economies.xlsx";
		String downloadsPath = "";

		if (System.getProperty("os.name").toLowerCase().contains("win")) {
			// Windows
			downloadsPath = userHome + "\\Downloads";
		} else if (System.getProperty("os.name").toLowerCase().contains("mac")) {
			// Mac
			downloadsPath = userHome + "/Downloads";
		}

		Path file = FileSystems.getDefault().getPath(downloadsPath, fileName);

		Workbook workbook = new XSSFWorkbook();
		Sheet sheet = workbook.createSheet("economies");

		// Crear encabezados de columnas
		Row headerRow = sheet.createRow(0);
		headerRow.createCell(0).setCellValue("ID de la Economía");
		headerRow.createCell(1).setCellValue("Modalidad");
		headerRow.createCell(2).setCellValue("Tipo de Economía");
		headerRow.createCell(3).setCellValue("Número de Operación");
		headerRow.createCell(4).setCellValue("Tipo de Persona");
		headerRow.createCell(5).setCellValue("Tipo de Documento");
		headerRow.createCell(6).setCellValue("Número de Documento");
		headerRow.createCell(7).setCellValue("Descripciones");
		headerRow.createCell(8).setCellValue("Monto");
		headerRow.createCell(9).setCellValue("Ingresos Totales");
		headerRow.createCell(10).setCellValue("Gastos Totales");
		headerRow.createCell(11).setCellValue("Diferencias");
		headerRow.createCell(12).setCellValue("Estado");
		headerRow.createCell(13).setCellValue("Fecha y Hora");

		// Llenar los datos de la lista en las filas de Excel
		int rowNum = 1;
		for (Economy economy : lista) {
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(economy.getEconomy_id());
			row.createCell(1).setCellValue(economy.getModality());
			row.createCell(2).setCellValue(economy.getEconomy_type());
			row.createCell(3).setCellValue(economy.getNumber_operation());
			row.createCell(4).setCellValue(economy.getPerson_type());
			row.createCell(5).setCellValue(economy.getDocument_type());
			row.createCell(6).setCellValue(economy.getDocument_number());
			row.createCell(7).setCellValue(economy.getDescriptions());
			row.createCell(8).setCellValue(economy.getAmount().doubleValue());
			row.createCell(9).setCellValue(economy.getTotal_incomes().doubleValue());
			row.createCell(10).setCellValue(economy.getTotal_expenses().doubleValue());
			row.createCell(11).setCellValue(economy.getDiferencity().doubleValue());
			row.createCell(12).setCellValue(economy.getStates());
			row.createCell(13).setCellValue(economy.getDate_hour().toString());
		}

		// Autoajustar el ancho de las columnas
		for (int i = 0; i < 14; i++) {
			sheet.autoSizeColumn(i);
		}

		response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		response.setHeader("Content-Disposition", "attachment; filename=" + fileName);

		try (OutputStream outputStream = response.getOutputStream()) {
			workbook.write(outputStream);
			System.out.println("Archivo Excel generado exitosamente en: " + file.toString());
		} catch (IOException e) {
			System.out.println("Error al generar el archivo Excel: " + e.getMessage());
		} finally {
			if (workbook != null) {
				try {
					workbook.close();
				} catch (IOException e) {
					System.out.println("Error al cerrar el workbook: " + e.getMessage());
				}
			}
		}
	}

	private void downloadFile(String filePath, HttpServletResponse response) throws IOException {
		// Obtener el nombre del archivo
		String fileName = filePath.substring(filePath.lastIndexOf('/') + 1);

		// Establecer las cabeceras de la respuesta HTTP
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");

		// Leer el archivo y escribir su contenido en la respuesta
		try (InputStream inputStream = new FileInputStream(filePath);
				OutputStream outputStream = response.getOutputStream()) {
			byte[] buffer = new byte[4096];
			int bytesRead;
			while ((bytesRead = inputStream.read(buffer)) != -1) {
				outputStream.write(buffer, 0, bytesRead);
			}
		}

		// Eliminar el archivo después de descargarlo
		Files.deleteIfExists(Paths.get(filePath));
	}

	private void EconomyProcesar(HttpServletRequest request, HttpServletResponse response) {
		// Obtener los datos del formulario
		String accion = request.getParameter("accion");
		String economyIdString = request.getParameter("economy_id");
		int economy_id = 0; // Valor por defecto en caso de error

		if (economyIdString != null && !economyIdString.isEmpty()) {
			try {
				economy_id = Integer.parseInt(economyIdString);
			} catch (NumberFormatException e) {
				ControllerUtil.responseJson(response, "El ID de la economía no es válido.");
				return;
			}
		}

		String modality = request.getParameter("modality");
		String economy_type = request.getParameter("economy_type");
		String number_operation = request.getParameter("number_operation");
		String person_type = request.getParameter("person_type");
		String document_type = request.getParameter("document_type");
		String document_number = request.getParameter("document_number");
		String descriptions = request.getParameter("descriptions");

		// Obtener los valores de los campos de cantidad, ingresos totales, gastos
		// totales y diferencial
		String amountString = request.getParameter("amount");

		// Asignar valores predeterminados de 0 si los valores son nulos o vacíos
		BigDecimal amount = (amountString != null && !amountString.isEmpty()) ? new BigDecimal(amountString)
				: BigDecimal.ZERO;

		// Proceso
		try {
			// Obtener la fecha y hora actual del servidor
			Date dateHour = new Date();

			Economy economy = new Economy(economy_id, modality, economy_type, number_operation, person_type,
					document_type, document_number, descriptions, amount, null, null, null, null, dateHour);

			switch (accion) {
			case ControllerUtil.CRUD_NUEVO:
				service.create(economy);

				// Obtener el registro creado
				Economy createdEconomy = service.getById(economy_id);

				// Aquí actualizamos el estado en la respuesta JSON
				createdEconomy.setStates("A");
				Gson gson = new Gson();
				String data = gson.toJson(createdEconomy);
				ControllerUtil.responseJson(response, data);
				break;
			case ControllerUtil.CRUD_EDITAR:
				service.update(economy);
				ControllerUtil.responseJson(response, "Economía actualizada exitosamente.");
				break;
			case ControllerUtil.CRUD_ELIMINAR:
				service.softDelete(economy_id);
				ControllerUtil.responseJson(response, "Economía eliminada exitosamente.");
				break;
			case ControllerUtil.CRUD_REACTIVAR:
				service.reactivate(economy_id);
				ControllerUtil.responseJson(response, "Economía reactivada exitosamente.");
				break;
			default:
				throw new IllegalArgumentException("Valor inesperado: " + accion);
			}
		} catch (Exception e) {
			ControllerUtil.responseJson(response, e.getMessage());
		}
	}

	private void EconomyBuscar(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Datos
		String economyType = request.getParameter("economy_type");
		String numberOperation = request.getParameter("number_operation");
		String documentNumber = request.getParameter("document_number");
		String states = request.getParameter("states");

		// Proceso
		Economy filter = new Economy();
		filter.setEconomy_type(economyType);
		filter.setNumber_operation(numberOperation);
		filter.setDocument_number(documentNumber);
		filter.setStates(states);
		List<Economy> lista = service.getFilters(filter);

		// Reporte
		request.setAttribute("listado", lista);
		RequestDispatcher rd = request.getRequestDispatcher("Economy.html");
		rd.forward(request, response);
	}

	private void EconomyBuscar2(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Datos
		String economyType = request.getParameter("economy_type");
		String numberOperation = request.getParameter("number_operation");
		String documentNumber = request.getParameter("document_number");
		String states = request.getParameter("states");

		// Proceso
		Economy filter = new Economy();
		filter.setEconomy_type(economyType);
		filter.setNumber_operation(numberOperation);
		filter.setDocument_number(documentNumber);
		filter.setStates(states);
		List<Economy> lista = service.getFilters(filter);

		// Preparando el JSON
		Gson gson = new Gson();
		String data = gson.toJson(lista);

		// Reporte
		ControllerUtil.responseJson(response, data);
	}

}
