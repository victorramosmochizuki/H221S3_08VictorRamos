package pe.edu.vallegrande.app.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.google.gson.Gson;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import pe.edu.vallegrande.app.model.Student;
import pe.edu.vallegrande.app.service.CrudStudentService;

@WebServlet({ "/StudentBuscar", "/StudentBuscar2", "/StudentProcesar", "/StudentDescargar" })
public class StudentController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private CrudStudentService service = new CrudStudentService();

	// Metodos URL
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = request.getServletPath();
		switch (path) {
		case "/StudentBuscar":
			studentBuscar(request, response);
			break;
		case "/StudentBuscar2":
			studentBuscar2(request, response);
			break;
		case "/StudentProcesar":
			studentProcesar(request, response);
			break;
//		case "/StudentDescargar":
//			studentDescargar(request, response);
//			break;
		}
	}

//	private void studentDescargar(HttpServletRequest request, HttpServletResponse response) throws IOException {
//		String type = request.getParameter("type");
//
//		List<Student> lista = service.getFilters(new Student());
//
//		if ("excel".equals(type)) {
//			generateExcel(lista, response);
//			String filePath = "students.xlsx";
//			downloadFile(filePath, response);
//		} else if ("pdf".equals(type)) {
//			generatePDF(lista, response);
//			String filePath = "students.pdf";
//			downloadFile(filePath, response);
//		} else if ("csv".equals(type)) {
//			generateCSV(lista, response); // Actualiza esta línea
//			String filePath = "students.csv";
//			downloadFile(filePath, response);
//		} else {
//			response.getWriter().write("Tipo de archivo inválido");
//		}
//	}

//	// Descarga CSV
//	private void generateCSV(List<Student> lista, HttpServletResponse response) {
//		try {
//			response.setContentType("text/csv");
//			response.setHeader("Content-Disposition", "attachment; filename=students.csv");
//
//			// Obtener el flujo de salida del servlet
//			PrintWriter writer = response.getWriter();
//
//			// Escribir encabezados de columna
//			writer.println(
//					"ID del Estudiante,Nombres,Apellidos,Tipo de Documento,Numero de Documento,Seccion,Celular,Correo Electronico,Documento del Padre,Documento de la Madre,Estado");
//
//			// Escribir datos de estudiantes
//			for (Student student : lista) {
//				writer.print(student.getStudent_id() + ",");
//				writer.print(student.getNames() + ",");
//				writer.print(student.getSurname() + ",");
//				writer.print(student.getDocument_type() + ",");
//				writer.print(student.getDocument_number() + ",");
//				writer.print(student.getDegree_section() + ",");
//				writer.print(student.getCellphone() + ",");
//				writer.print(student.getEmail() + ",");
//				writer.print(student.getFather_document() + ",");
//				writer.print(student.getMother_document() + ",");
//				writer.println(student.getStates());
//			}
//
//			writer.close();
//		} catch (IOException e) {
//			System.out.println("Error al generar el archivo CSV: " + e.getMessage());
//		}
//	}
//
//	// Descarga PDF
//	private void generatePDF(List<Student> lista, HttpServletResponse response) {
//		try {
//			response.setContentType("application/pdf");
//			response.setHeader("Content-Disposition", "attachment; filename=students.pdf");
//
//			Document document = new Document();
//			PdfWriter.getInstance(document, response.getOutputStream());
//			document.open();
//
//			// Crear la tabla con 11 columnas
//			PdfPTable table = new PdfPTable(11);
//
//			// Ajustar el ancho de la tabla
//			table.setTotalWidth(document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin());
//
//			// Añadir los encabezados de columna a la tabla
//			table.addCell("ID del Estudiante");
//			table.addCell("Nombres");
//			table.addCell("Apellidos");
//			table.addCell("Tipo de Documento");
//			table.addCell("Número de Documento");
//			table.addCell("Sección");
//			table.addCell("Celular");
//			table.addCell("Correo Electrónico");
//			table.addCell("Documento del Padre");
//			table.addCell("Documento de la Madre");
//			table.addCell("Estado");
//
//			// Añadir los datos de los estudiantes a la tabla
//			for (Student student : lista) {
//				table.addCell(String.valueOf(student.getStudent_id())); // Convertir el entero a String
//				table.addCell(student.getNames());
//				table.addCell(student.getSurname());
//				table.addCell(student.getDocument_type());
//				table.addCell(student.getDocument_number());
//				table.addCell(student.getDegree_section());
//				table.addCell(student.getCellphone());
//				table.addCell(student.getEmail());
//				table.addCell(student.getFather_document());
//				table.addCell(student.getMother_document());
//				table.addCell(student.getStates());
//			}
//
//			// Añadir la tabla al documento
//			document.add(table);
//
//			document.close();
//			System.out.println("Archivo PDF generado exitosamente.");
//		} catch (DocumentException e) {
//			System.out.println("Error al generar el archivo PDF: " + e.getMessage());
//		} catch (IOException e) {
//			System.out.println("Error de entrada/salida al generar el archivo PDF: " + e.getMessage());
//		}
//	}

//	// Descarga excel
//	private void generateExcel(List<Student> lista, HttpServletResponse response) {
//		try (Workbook workbook = new XSSFWorkbook()) {
//			// Crear hoja de Excel
//			Sheet sheet = workbook.createSheet("students");
//
//			// Crear encabezados de columnas
//			Row headerRow = sheet.createRow(0);
//			headerRow.createCell(0).setCellValue("ID del Estudiante");
//			headerRow.createCell(1).setCellValue("Nombres");
//			headerRow.createCell(2).setCellValue("Apellidos");
//			headerRow.createCell(3).setCellValue("Tipo de Documento");
//			headerRow.createCell(4).setCellValue("Número de Documento");
//			headerRow.createCell(5).setCellValue("Grado y Sección");
//			headerRow.createCell(6).setCellValue("Celular");
//			headerRow.createCell(7).setCellValue("Correo Electrónico");
//			headerRow.createCell(8).setCellValue("Documento del Padre");
//			headerRow.createCell(9).setCellValue("Documento de la Madre");
//			headerRow.createCell(10).setCellValue("Estado");
//
//			// Llenar los datos de la lista en las filas de Excel
//			int rowNum = 1;
//			for (Student student : lista) {
//				Row row = sheet.createRow(rowNum++);
//				row.createCell(0).setCellValue(student.getStudent_id());
//				row.createCell(1).setCellValue(student.getNames());
//				row.createCell(2).setCellValue(student.getSurname());
//				row.createCell(3).setCellValue(student.getDocument_type());
//				row.createCell(4).setCellValue(student.getDocument_number());
//				row.createCell(5).setCellValue(student.getDegree_section());
//				row.createCell(6).setCellValue(student.getCellphone());
//				row.createCell(7).setCellValue(student.getEmail());
//				row.createCell(8).setCellValue(student.getFather_document());
//				row.createCell(9).setCellValue(student.getMother_document());
//				row.createCell(10).setCellValue(student.getStates());
//			}
//
//			// Autoajustar el ancho de las columnas
//			for (int i = 0; i < 11; i++) {
//				sheet.autoSizeColumn(i);
//			}
//
//			// Establecer el tipo de contenido de la respuesta
//			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
//
//			// Establecer el encabezado de la respuesta para el archivo adjunto
//			String fileName = "students.xlsx";
//			response.setHeader("Content-Disposition", "attachment; filename=" + fileName);
//
//			// Obtener el flujo de salida de la respuesta
//			ServletOutputStream outputStream = response.getOutputStream();
//
//			// Escribir el libro de Excel en el flujo de salida de la respuesta
//			workbook.write(outputStream);
//			workbook.close();
//			outputStream.close();
//
//			System.out.println("Archivo Excel generado exitosamente.");
//		} catch (IOException e) {
//			System.out.println("Error al generar el archivo Excel: " + e.getMessage());
//		}
//	}

	private void downloadFile(String filePath, HttpServletResponse response) throws IOException {
		String fileName = filePath.substring(filePath.lastIndexOf('/') + 1);
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");

		try (InputStream inputStream = new FileInputStream(filePath);
				OutputStream outputStream = response.getOutputStream()) {
			byte[] buffer = new byte[4096];
			int bytesRead;
			while ((bytesRead = inputStream.read(buffer)) != -1) {
				outputStream.write(buffer, 0, bytesRead);
			}
		}

		Files.deleteIfExists(Path.of(filePath));
	}

	private void studentProcesar(HttpServletRequest request, HttpServletResponse response) {
		// Datos
		String accion = request.getParameter("accion");
		String student_idString = request.getParameter("student_id");
		int student_id = 0; // Valor por defecto en caso de error

		if (student_idString != null && !student_idString.isEmpty()) {
			try {
				student_id = Integer.parseInt(student_idString);
			} catch (NumberFormatException e) {
				ControllerUtil.responseJson(response, "El ID del estudiante no es válido.");
				return;
			}
		}

		String names = request.getParameter("names");
		String surname = request.getParameter("surname");
		String document_type = request.getParameter("document_type");
		String document_number = request.getParameter("document_number");
		//String degree_section = request.getParameter("degree_section");
		String carrera = request.getParameter("carrera");
		String ciclo = request.getParameter("ciclo");
		String cellphone = request.getParameter("cellphone");
		String email = request.getParameter("email");
		String father_document = request.getParameter("father_document");
		String mother_document = request.getParameter("mother_document");
		String states = request.getParameter("states");

		// Proceso
		try {
			Student student = new Student(student_id, names, surname, document_type, document_number, carrera, ciclo,
					cellphone, email, father_document, mother_document, states);
			switch (accion) {
			case ControllerUtil.CRUD_NUEVO:
				service.create(student);
				break;
			case ControllerUtil.CRUD_EDITAR:
				service.update(student);
				break;
			case ControllerUtil.CRUD_ELIMINAR:
				service.softDelete(student_id);
				break;
			case ControllerUtil.CRUD_REACTIVAR:
				service.reactivate(student_id);
				states = "A"; // Actualizar el estado a "A"
				break; // Agregamos el caso para reactivar y cambiamos el estado a "A"
			default:
				throw new IllegalArgumentException("Unexpected value: " + accion);
			}

			// Aquí actualizamos el estado en la respuesta JSON
			student.setStates(states);
			Gson gson = new Gson();
			String data = gson.toJson(student);
			ControllerUtil.responseJson(response, data);
		} catch (Exception e) {
			ControllerUtil.responseJson(response, e.getMessage());
		}
	}

	private void studentBuscar(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Datos
		String names = request.getParameter("names");
		String surname = request.getParameter("surname");
		String document_number = request.getParameter("document_number");
		//String degree_section = request.getParameter("degree_section");
		String carrera = request.getParameter("carrera");
		String ciclo = request.getParameter("ciclo");
		String states = request.getParameter("states");

		// Proceso
		Student student = new Student();
		student.setNames(names);
		student.setSurname(surname);
		student.setDocument_number(document_number);
		//student.setDegree_section(degree_section);
		student.setCarrera(carrera);
		student.setCiclo(ciclo);
		student.setStates(states);
		List<Student> lista = service.getFilters(student);

		// Reporte
		request.setAttribute("listado", lista);
		RequestDispatcher rd = request.getRequestDispatcher("Student.html");
		rd.forward(request, response);
	}

	private void studentBuscar2(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Datos
		String names = request.getParameter("names");
		String surname = request.getParameter("surname");
		String document_number = request.getParameter("document_number");
		//String degree_section = request.getParameter("degree_section");
		String carrera = request.getParameter("carrera");
		String ciclo = request.getParameter("ciclo");
		String states = request.getParameter("states");

		// Proceso
		Student student = new Student();
		student.setNames(names);
		student.setSurname(surname);
		student.setDocument_number(document_number);
		//student.setDegree_section(degree_section);
		student.setCarrera(carrera);
		student.setCiclo(ciclo);
		student.setStates(states);
		List<Student> lista = service.getFilters(student);

		// Preparando el JSON
		Gson gson = new Gson();
		String data = gson.toJson(lista);

		// Reporte
		ControllerUtil.responseJson(response, data);
	}
}
