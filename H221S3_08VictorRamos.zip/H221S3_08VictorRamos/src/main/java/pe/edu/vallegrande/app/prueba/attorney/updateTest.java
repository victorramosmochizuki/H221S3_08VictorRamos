package pe.edu.vallegrande.app.prueba.attorney;

import pe.edu.vallegrande.app.model.Attorney;
import pe.edu.vallegrande.app.service.CrudAttorneyService;

public class updateTest {
    public static void main(String[] args) {
        // Crear un nuevo objeto Attorney con los datos actualizados
        Attorney attorney = new Attorney();
        attorney.setAttorney_id(1); // Reemplaza con el ID del abogado que deseas actualizar
        attorney.setNames("John");
        attorney.setSurname("Doe");
        attorney.setDocument_type("DNI");
        attorney.setDocument_number("AB123456");
        attorney.setCellphone("123456789");
        attorney.setEmail("johndoe@example.com");
        
        // Crear una instancia de CrudAttorneyService
        CrudAttorneyService attorneyService = new CrudAttorneyService();
        
        // Llamar al método update para actualizar el abogado
        attorneyService.update(attorney);
    }
}
