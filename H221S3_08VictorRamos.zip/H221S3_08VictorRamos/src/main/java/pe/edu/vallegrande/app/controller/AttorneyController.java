package pe.edu.vallegrande.app.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.google.gson.Gson;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import pe.edu.vallegrande.app.model.Attorney;
import pe.edu.vallegrande.app.service.CrudAttorneyService;

@WebServlet({ "/AttorneyBuscar", "/AttorneyBuscar2", "/AttorneyProcesar", "/AttorneyDescargar" })
public class AttorneyController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private CrudAttorneyService service = new CrudAttorneyService();

	// Metodos URL
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = request.getServletPath();
		switch (path) {
		case "/AttorneyBuscar":
			AttorneyBuscar(request, response);
			break;
		case "/AttorneyBuscar2":
			AttorneyBuscar2(request, response);
			break;
		case "/AttorneyProcesar":
			AttorneyProcesar(request, response);
			break;
		case "/AttorneyDescargar":
			AttorneyDescargar(request, response);
			break;
		}
	}

	private void AttorneyDescargar(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String type = request.getParameter("type");

		List<Attorney> lista = service.getFilters(new Attorney());

		if ("excel".equals(type)) {
			generateExcel(lista, response);
			String filePath = "attorney.xlsx";
			downloadFile(filePath, response);
		} else if ("pdf".equals(type)) {
			generatePDF(lista, response);
			String filePath = "attorney.pdf";
			downloadFile(filePath, response);
		} else if ("csv".equals(type)) {
			generateCSV(lista, response);
			String filePath = "atorney.csv";
			downloadFile(filePath, response);
		} else {
			response.getWriter().write("Tipo de archivo inválido");
		}
	}

	private void generateCSV(List<Attorney> lista, HttpServletResponse response) {
		// Obtener el directorio de inicio del usuario
		String userHome = System.getProperty("user.home");

		// Definir el nombre del archivo
		String fileName = "apoderados.csv";

		// Obtener la ruta completa de la carpeta de descargas
		String downloadsPath = "";
		if (System.getProperty("os.name").toLowerCase().contains("win")) {
			// Windows
			downloadsPath = userHome + "\\Downloads";
		} else if (System.getProperty("os.name").toLowerCase().contains("mac")) {
			// Mac
			downloadsPath = userHome + "/Downloads";
		}

		// Crear la ruta completa del archivo
		Path file = FileSystems.getDefault().getPath(downloadsPath, fileName);

		response.setContentType("text/csv");
		response.setHeader("Content-Disposition", "attachment; filename=" + fileName);

		try (PrintWriter writer = response.getWriter()) {
			// Escribir encabezados de columna
			writer.println(
					"ID del Apoderado,Nombres,Apellidos,Tipo de Documento,Numero de Documento,Celular,Correo Electronico,Estado");

			// Escribir datos de apoderados
			for (Attorney attorney : lista) {
				writer.print(attorney.getAttorney_id() + ",");
				writer.print(attorney.getNames() + ",");
				writer.print(attorney.getSurname() + ",");
				writer.print(attorney.getDocument_type() + ",");
				writer.print(attorney.getDocument_number() + ",");
				writer.print(attorney.getCellphone() + ",");
				writer.print(attorney.getEmail() + ",");
				writer.println(attorney.getStates());
			}

			System.out.println("Archivo CSV generado exitosamente en: " + file.toString());
		} catch (IOException e) {
			System.out.println("Error al generar el archivo CSV: " + e.getMessage());
		}
	}

	private void generatePDF(List<Attorney> lista, HttpServletResponse response) {
		String userHome = System.getProperty("user.home");
		String fileName = "apoderados.pdf";
		String downloadsPath = "";

		if (System.getProperty("os.name").toLowerCase().contains("win")) {
			// Windows
			downloadsPath = userHome + "\\Downloads";
		} else if (System.getProperty("os.name").toLowerCase().contains("mac")) {
			// Mac
			downloadsPath = userHome + "/Downloads";
		}

		Path file = FileSystems.getDefault().getPath(downloadsPath, fileName);

		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment; filename=" + fileName);

		try (OutputStream outputStream = response.getOutputStream()) {
			Document document = new Document();
			document.setPageSize(PageSize.A4.rotate()); // Configurar orientación apaisada
			PdfWriter.getInstance(document, outputStream);
			document.open();

			// Crear la tabla con 8 columnas
			PdfPTable table = new PdfPTable(8);

			// Ajustar el ancho de la tabla
			table.setTotalWidth(document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin());

			// Añadir los encabezados de columna a la tabla
			table.addCell("ID del Apoderado");
			table.addCell("Nombres");
			table.addCell("Apellidos");
			table.addCell("Tipo de Documento");
			table.addCell("Número de Documento");
			table.addCell("Celular");
			table.addCell("Correo Electrónico");
			table.addCell("Estado");

			// Añadir los datos de los apoderados a la tabla
			for (Attorney attorney : lista) {
				table.addCell(String.valueOf(attorney.getAttorney_id())); // Convertir el entero a String
				table.addCell(attorney.getNames());
				table.addCell(attorney.getSurname());
				table.addCell(attorney.getDocument_type());
				table.addCell(attorney.getDocument_number());
				table.addCell(attorney.getCellphone());
				table.addCell(attorney.getEmail());
				table.addCell(attorney.getStates());
			}

			// Añadir la tabla al documento
			document.add(table);

			document.close();
			System.out.println("Archivo PDF generado exitosamente en: " + file.toString());
		} catch (DocumentException e) {
			System.out.println("Error al generar el archivo PDF: " + e.getMessage());
		} catch (IOException e) {
			System.out.println("Error al escribir en el OutputStream: " + e.getMessage());
		}
	}

	private void generateExcel(List<Attorney> lista, HttpServletResponse response) {
		String userHome = System.getProperty("user.home");
		String fileName = "apoderados.xlsx";
		String downloadsPath = "";

		if (System.getProperty("os.name").toLowerCase().contains("win")) {
			// Windows
			downloadsPath = userHome + "\\Downloads";
		} else if (System.getProperty("os.name").toLowerCase().contains("mac")) {
			// Mac
			downloadsPath = userHome + "/Downloads";
		}

		Path file = FileSystems.getDefault().getPath(downloadsPath, fileName);

		Workbook workbook = new XSSFWorkbook();
		Sheet sheet = workbook.createSheet("apoderados");

		// Crear encabezados de columnas
		Row headerRow = sheet.createRow(0);
		headerRow.createCell(0).setCellValue("ID del Apoderado");
		headerRow.createCell(1).setCellValue("Nombres");
		headerRow.createCell(2).setCellValue("Apellidos");
		headerRow.createCell(3).setCellValue("Tipo de Documento");
		headerRow.createCell(4).setCellValue("Número de Documento");
		headerRow.createCell(5).setCellValue("Celular");
		headerRow.createCell(6).setCellValue("Correo Electrónico");
		headerRow.createCell(7).setCellValue("Estado");

		// Llenar los datos de la lista en las filas de Excel
		int rowNum = 1;
		for (Attorney attorney : lista) {
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(attorney.getAttorney_id());
			row.createCell(1).setCellValue(attorney.getNames());
			row.createCell(2).setCellValue(attorney.getSurname());
			row.createCell(3).setCellValue(attorney.getDocument_type());
			row.createCell(4).setCellValue(attorney.getDocument_number());
			row.createCell(5).setCellValue(attorney.getCellphone());
			row.createCell(6).setCellValue(attorney.getEmail());
			row.createCell(7).setCellValue(attorney.getStates());
		}

		// Autoajustar el ancho de las columnas
		for (int i = 0; i < 8; i++) {
			sheet.autoSizeColumn(i);
		}

		response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		response.setHeader("Content-Disposition", "attachment; filename=" + fileName);

		try (OutputStream outputStream = response.getOutputStream()) {
			workbook.write(outputStream);
			System.out.println("Archivo Excel generado exitosamente en: " + file.toString());
		} catch (IOException e) {
			System.out.println("Error al generar el archivo Excel: " + e.getMessage());
		} finally {
			if (workbook != null) {
				try {
					workbook.close();
				} catch (IOException e) {
					System.out.println("Error al cerrar el workbook: " + e.getMessage());
				}
			}
		}
	}

	private void downloadFile(String filePath, HttpServletResponse response) throws IOException {
		// Obtener el nombre del archivo
		String fileName = filePath.substring(filePath.lastIndexOf('/') + 1);

		// Establecer las cabeceras de la respuesta HTTP
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");

		// Leer el archivo y escribir su contenido en la respuesta
		try (InputStream inputStream = new FileInputStream(filePath);
				OutputStream outputStream = response.getOutputStream()) {
			byte[] buffer = new byte[4096];
			int bytesRead;
			while ((bytesRead = inputStream.read(buffer)) != -1) {
				outputStream.write(buffer, 0, bytesRead);
			}
		}

		// Eliminar el archivo después de descargarlo
		Files.deleteIfExists(Paths.get(filePath));
	}

	private void AttorneyProcesar(HttpServletRequest request, HttpServletResponse response) {
		// Datos
		String accion = request.getParameter("accion");
		String attorneyIdString = request.getParameter("attorney_id");
		int attorney_id = 0; // Valor por defecto en caso de error

		if (attorneyIdString != null && !attorneyIdString.isEmpty()) {
			try {
				attorney_id = Integer.parseInt(attorneyIdString);
			} catch (NumberFormatException e) {
				ControllerUtil.responseJson(response, "El ID del abogado no es válido.");
				return;
			}
		}

		String names = request.getParameter("names");
		String surname = request.getParameter("surname");
		String documentType = request.getParameter("document_type");
		String documentNumber = request.getParameter("document_number");
		String cellphone = request.getParameter("cellphone");
		String email = request.getParameter("email");
		String states = request.getParameter("states");

		// Proceso
		try {
			Attorney attorney = new Attorney(attorney_id, names, surname, documentType, documentNumber, cellphone,
					email, states);
			switch (accion) {
			case ControllerUtil.CRUD_NUEVO:
				service.create(attorney);
				break;
			case ControllerUtil.CRUD_EDITAR:
				service.update(attorney);
				break;
			case ControllerUtil.CRUD_ELIMINAR:
				service.softDelete(attorney_id);
				break;
			case ControllerUtil.CRUD_REACTIVAR:
				service.reactivate(attorney_id);
				states = "A"; // Actualizar el estado a "A"
				break; // Agregamos el caso para reactivar y cambiamos el estado a "A"
			default:
				throw new IllegalArgumentException("Unexpected value: " + accion);
			}

			// Aquí actualizamos el estado en la respuesta JSON
			attorney.setStates(states);
			Gson gson = new Gson();
			String data = gson.toJson(attorney);
			ControllerUtil.responseJson(response, data);
		} catch (Exception e) {
			ControllerUtil.responseJson(response, e.getMessage());
		}
	}

	private void AttorneyBuscar(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Datos
		String names = request.getParameter("names");
		String surname = request.getParameter("surname");
		String document_number = request.getParameter("document_number");
		String states = request.getParameter("states");

		// Proceso
		Attorney attorney = new Attorney();
		attorney.setNames(names);
		attorney.setSurname(surname);
		attorney.setDocument_number(document_number);
		attorney.setStates(states);
		List<Attorney> lista = service.getFilters(attorney);

		// Reporte
		request.setAttribute("listado", lista);
		RequestDispatcher rd = request.getRequestDispatcher("Attorney.html");
		rd.forward(request, response);
	}

	private void AttorneyBuscar2(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Datos
		String names = request.getParameter("names");
		String surname = request.getParameter("surname");
		String document_number = request.getParameter("document_number");
		String states = request.getParameter("states");

		// Proceso
		Attorney attorney = new Attorney();
		attorney.setNames(names);
		attorney.setSurname(surname);
		attorney.setDocument_number(document_number);
		attorney.setStates(states);
		List<Attorney> lista = service.getFilters(attorney);

		// Preparando el JSON
		Gson gson = new Gson();
		String data = gson.toJson(lista);

		// Reporte
		ControllerUtil.responseJson(response, data);
	}
}
