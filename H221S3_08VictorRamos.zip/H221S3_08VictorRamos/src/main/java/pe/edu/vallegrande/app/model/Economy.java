package pe.edu.vallegrande.app.model;

import java.math.BigDecimal;
import java.util.Date;

public class Economy {

    private int economy_id;
    private String modality;
    private String economy_type;
    private String number_operation;
    private String person_type;
    private String document_type;
    private String document_number;
    private String descriptions;
    private BigDecimal amount;
    private BigDecimal total_incomes;
    private BigDecimal total_expenses;
    private BigDecimal diferencity;
    private String states;
    private Date date_hour;

    public Economy() {
    }

    public Economy(int economy_id, String modality, String economy_type, String number_operation, String person_type,
                   String document_type, String document_number, String descriptions, BigDecimal amount,
                   BigDecimal total_incomes, BigDecimal total_expenses, BigDecimal diferencity, String states,
                   Date date_hour) {
        this.economy_id = economy_id;
        this.modality = modality;
        this.economy_type = economy_type;
        this.number_operation = number_operation;
        this.person_type = person_type;
        this.document_type = document_type;
        this.document_number = document_number;
        this.descriptions = descriptions;
        this.amount = amount;
        this.total_incomes = total_incomes;
        this.total_expenses = total_expenses;
        this.diferencity = diferencity;
        this.states = states;
        this.date_hour = date_hour;
    }

    public int getEconomy_id() {
        return economy_id;
    }

    public void setEconomy_id(int economy_id) {
        this.economy_id = economy_id;
    }

    public String getModality() {
        return modality;
    }

    public void setModality(String modality) {
        this.modality = modality;
    }

    public String getEconomy_type() {
        return economy_type;
    }

    public void setEconomy_type(String economy_type) {
        this.economy_type = economy_type;
    }

    public String getNumber_operation() {
        return number_operation;
    }

    public void setNumber_operation(String number_operation) {
        this.number_operation = number_operation;
    }

    public String getPerson_type() {
        return person_type;
    }

    public void setPerson_type(String person_type) {
        this.person_type = person_type;
    }

    public String getDocument_type() {
        return document_type;
    }

    public void setDocument_type(String document_type) {
        this.document_type = document_type;
    }

    public String getDocument_number() {
        return document_number;
    }

    public void setDocument_number(String document_number) {
        this.document_number = document_number;
    }

    public String getDescriptions() {
        return descriptions;
    }

    public void setDescriptions(String descriptions) {
        this.descriptions = descriptions;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getTotal_incomes() {
        return total_incomes;
    }

    public void setTotal_incomes(BigDecimal total_incomes) {
        this.total_incomes = total_incomes;
    }

    public BigDecimal getTotal_expenses() {
        return total_expenses;
    }

    public void setTotal_expenses(BigDecimal total_expenses) {
        this.total_expenses = total_expenses;
    }

    public BigDecimal getDiferencity() {
        return diferencity;
    }

    public void setDiferencity(BigDecimal diferencity) {
        this.diferencity = diferencity;
    }

    public String getStates() {
        return states;
    }

    public void setStates(String states) {
        this.states = states;
    }

    public Date getDate_hour() {
        return date_hour;
    }

    public void setDate_hour(Date date_hour) {
        this.date_hour = date_hour;
    }

    @Override
    public String toString() {
        String data = "[economy_id: " + this.economy_id;
        data += ", modality: " + this.modality;
        data += ", economy_type: " + this.economy_type;
        data += ", number_operation: " + this.number_operation;
        data += ", person_type: " + this.person_type;
        data += ", document_type: " + this.document_type;
        data += ", document_number: " + this.document_number;
        data += ", descriptions: " + this.descriptions;
        data += ", amount: " + this.amount;
        data += ", total_incomes: " + this.total_incomes;
        data += ", total_expenses: " + this.total_expenses;
        data += ", diferencias: " + this.diferencity;
        data += ", states: " + this.states;
        data += ", date_hour: " + this.date_hour;

        return data;
    }
}
