package pe.edu.vallegrande.app.model;

public class Student {

    private int student_id;
    private String names;
    private String surname;
    private String document_type;
    private String document_number;
    private String carrera;
    private String ciclo;
    private String cellphone;
    private String email;
    private String father_document;
    private String mother_document;
    private String states;

    public Student() {
    }

    public Student(int student_id, String names, String surname, String document_type, String document_number,
    		
                   String carrera, String ciclo, String cellphone, String email, String father_document, String mother_document, String states) {
        
    	
    	
    	this.student_id = student_id;
        this.names = names;
        this.surname = surname;
        this.document_type = document_type;
        this.document_number = document_number;
        this.carrera = carrera;
        this.ciclo = ciclo;
        this.cellphone = cellphone;
        this.email = email;
        this.father_document = father_document;
        this.mother_document = mother_document;
        this.states = states;
    }

    public int getStudent_id() {
        return student_id;
    }

    public void setStudent_id(int student_id) {
        this.student_id = student_id;
    }

    public String getNames() {
        return names;
    }

    public void setNames(String names) {
        this.names = names;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getDocument_type() {
        return document_type;
    }

    public void setDocument_type(String document_type) {
        this.document_type = document_type;
    }

    public String getDocument_number() {
        return document_number;
    }

    public void setDocument_number(String document_number) {
        this.document_number = document_number;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }
    
    
    public String getCiclo() {
        return ciclo;
    }

    public void setCiclo(String ciclo) {
        this.ciclo = ciclo;
    }
    
    
    

    public String getCellphone() {
        return cellphone;
    }

    public void setCellphone(String cellphone) {
        this.cellphone = cellphone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFather_document() {
        return father_document;
    }

    public void setFather_document(String father_document) {
        this.father_document = father_document;
    }

    public String getMother_document() {
        return mother_document;
    }

    public void setMother_document(String mother_document) {
        this.mother_document = mother_document;
    }

    public String getStates() {
        return states;
    }

    public void setStates(String states) {
        this.states = states;
    }

    @Override
    public String toString() {
        String data = "[student_id: " + this.student_id;
        data += ", names: " + this.names;
        data += ", surname: " + this.surname;
        data += ", document_type: " + this.document_type;
        data += ", document_number: " + this.document_number;
       // data += ", degree_section: " + this.degree_section;
        data += ", carrera: " + this.carrera;
        data += ", ciclo: " + this.ciclo;
        data += ", cellphone: " + this.cellphone;
        data += ", email: " + this.email;
        data += ", father_document: " + this.father_document;
        data += ", mother_document: " + this.mother_document;
        data += ", states: " + this.states;

        return data;
    }
}
