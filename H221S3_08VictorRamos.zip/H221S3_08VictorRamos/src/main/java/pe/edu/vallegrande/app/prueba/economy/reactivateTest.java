package pe.edu.vallegrande.app.prueba.economy;

import pe.edu.vallegrande.app.service.CrudEconomyService;

public class reactivateTest {
    public static void main(String[] args) {
        // ID del registro de economy a reactivar
        int economyId = 2; // Reemplaza con el ID del registro de economy que deseas reactivar
        
        // Crear una instancia de CrudEconomyService
        CrudEconomyService economyService = new CrudEconomyService();
        
        // Llamar al método reactivate para reactivar el registro de economy
        economyService.reactivate(economyId);
    }
}
