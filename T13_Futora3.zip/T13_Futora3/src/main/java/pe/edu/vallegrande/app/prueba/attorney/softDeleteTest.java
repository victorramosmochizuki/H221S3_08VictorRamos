package pe.edu.vallegrande.app.prueba.attorney;

import pe.edu.vallegrande.app.service.CrudAttorneyService;

public class softDeleteTest {
    public static void main(String[] args) {
        // ID del abogado a eliminar
        int attorneyId = 1; // Reemplaza con el ID del abogado que deseas eliminar
        
        // Crear una instancia de CrudAttorneyService
        CrudAttorneyService attorneyService = new CrudAttorneyService();
        
        // Llamar al método softDelete para eliminar suavemente al abogado
        attorneyService.softDelete(attorneyId);
    }
}
