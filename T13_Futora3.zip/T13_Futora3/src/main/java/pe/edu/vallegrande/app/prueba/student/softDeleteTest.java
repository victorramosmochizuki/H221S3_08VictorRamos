package pe.edu.vallegrande.app.prueba.student;

import pe.edu.vallegrande.app.service.CrudStudentService;

public class softDeleteTest {
    public static void main(String[] args) {
        // ID del abogado a eliminar
        int student_id = 1; // Reemplaza con el ID del abogado que deseas eliminar
        
        // Crear una instancia de CrudAttorneyService
        CrudStudentService studentService = new CrudStudentService();
        
        // Llamar al método softDelete para eliminar suavemente al abogado
        studentService.softDelete(student_id);
    }
}
