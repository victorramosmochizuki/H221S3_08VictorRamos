package pe.edu.vallegrande.app.prueba.student;

import pe.edu.vallegrande.app.model.Student;
import pe.edu.vallegrande.app.service.CrudStudentService;

public class updateTest {
    public static void main(String[] args) {
        // Crear un nuevo objeto Attorney con los datos actualizados
        Student student = new Student();
        student.setStudent_id(1); // Reemplaza con el ID del abogado que deseas actualizar
        student.setNames("John");
        student.setSurname("Doe");
        student.setDocument_type("DNI");
        student.setDocument_number("AB123456");
        //student.setDegree_section("A1");  
        student.setCarrera("analisis de sistemas");
        student.setCiclo("1");
        student.setCellphone("123456789");
        student.setEmail("johndoe@example.com");

        // Crear una instancia de CrudAttorneyService
        CrudStudentService studentService = new CrudStudentService();

        // Llamar al método update para actualizar el abogado
        studentService.update(student);
    }
}
