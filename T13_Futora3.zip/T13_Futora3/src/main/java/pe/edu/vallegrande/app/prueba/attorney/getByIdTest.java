package pe.edu.vallegrande.app.prueba.attorney;

import pe.edu.vallegrande.app.model.Attorney;
import pe.edu.vallegrande.app.service.CrudAttorneyService;

public class getByIdTest {
    public static void main(String[] args) {
        // ID del abogado a buscar
        int attorneyId = 1; // Reemplaza con el ID del abogado que deseas buscar
        
        // Crear una instancia de CrudAttorneyService
        CrudAttorneyService attorneyService = new CrudAttorneyService();
        
        // Llamar al método getById para obtener el abogado por su ID
        Attorney attorney = attorneyService.getById(attorneyId);
        
        // Imprimir el abogado obtenido
        if (attorney != null) {
            System.out.println("Apoderado encontrado:");
            System.out.println(attorney);
        } else {
            System.out.println("No se encontró ningún apoderado con el ID proporcionado: " + attorneyId);
        }
    }
}
