package pe.edu.vallegrande.app.prueba.economy;

import pe.edu.vallegrande.app.model.Economy;
import pe.edu.vallegrande.app.service.CrudEconomyService;

import java.math.BigDecimal;

public class createTest {
    public static void main(String[] args) {
        CrudEconomyService service = new CrudEconomyService();

        // Crear un objeto Economy con los datos del registro a insertar
        Economy economy = new Economy();
        economy.setModality("EF");
        economy.setEconomy_type("IN");
        economy.setNumber_operation("000007");
        economy.setPerson_type("AP");
        economy.setDocument_type("DNI");
        economy.setDocument_number("87654321");
        economy.setDescriptions("Ingreso adicional");
        economy.setAmount(new BigDecimal("200.00"));

        // Llamar al método create para insertar el registro y realizar las actualizaciones
        service.create(economy);
    }
}
