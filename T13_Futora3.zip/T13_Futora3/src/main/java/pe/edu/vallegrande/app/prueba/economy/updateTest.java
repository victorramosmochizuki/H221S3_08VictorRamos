package pe.edu.vallegrande.app.prueba.economy;

import pe.edu.vallegrande.app.model.Economy;
import pe.edu.vallegrande.app.service.CrudEconomyService;

import java.math.BigDecimal;

public class updateTest {
    public static void main(String[] args) {
        // Crear una instancia del servicio
        CrudEconomyService economyService = new CrudEconomyService();

        // Crear un objeto Economy con los datos del registro a actualizar
        Economy economy = new Economy();
        economy.setEconomy_id(2); // Reemplaza con el ID del registro que deseas actualizar
        economy.setModality("EF"); // Asignar un valor válido a modality
        economy.setEconomy_type("EG");
        economy.setNumber_operation("Operda");
        economy.setPerson_type("AP");
        economy.setDocument_type("DNI");
        economy.setDocument_number("11 1");
        economy.setDescriptions("Descr izada");
        economy.setAmount(BigDecimal.valueOf(150.00));

        // Llamar al método update para actualizar el registro
        economyService.update(economy);
    }
}
