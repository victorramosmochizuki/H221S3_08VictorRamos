package pe.edu.vallegrande.app.prueba.economy;

import pe.edu.vallegrande.app.model.Economy;
import pe.edu.vallegrande.app.service.CrudEconomyService;

import java.util.List;

public class getAllTest {
    public static void main(String[] args) {
        // Crear una instancia del servicio
        CrudEconomyService economyService = new CrudEconomyService();

        // Obtener todos los registros
        List<Economy> economyList = economyService.getAll();

        // Verificar si se obtuvieron registros
        if (economyList.isEmpty()) {
            System.out.println("No se encontraron registros de Economy.");
        } else {
            System.out.println("Registros de Economy encontrados:");
            for (Economy economy : economyList) {
                System.out.println(economy);
            }
        }
    }
}
