package pe.edu.vallegrande.app.prueba.student;

import pe.edu.vallegrande.app.model.Student;
import pe.edu.vallegrande.app.service.CrudStudentService;

public class getByIdTest {
    public static void main(String[] args) {
        // ID del estudiante a buscar
        int studentId = 1; // Reemplaza con el ID del estudiante que deseas buscar
        
        // Crear una instancia de CrudStudentService
        CrudStudentService studentService = new CrudStudentService();
        
        // Llamar al método getById para obtener el estudiante por su ID
        Student student = studentService.getById(studentId);
        
        // Imprimir el estudiante obtenido
        if (student != null) {
            System.out.println("Estudiante encontrado:");
            System.out.println(student);
        } else {
            System.out.println("No se encontró ningún estudiante con el ID proporcionado: " + studentId);
        }
    }
}
