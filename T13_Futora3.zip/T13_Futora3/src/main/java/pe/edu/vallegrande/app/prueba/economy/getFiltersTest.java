package pe.edu.vallegrande.app.prueba.economy;

import pe.edu.vallegrande.app.model.Economy;
import pe.edu.vallegrande.app.service.CrudEconomyService;

import java.util.List;

public class getFiltersTest {
    public static void main(String[] args) {
        // Crear una instancia de CrudEconomyService
        CrudEconomyService economyService = new CrudEconomyService();

        // Crear un objeto Economy con los valores de los filtros
        Economy filter = new Economy();
        filter.setEconomy_type(null);
        filter.setNumber_operation(null);
        filter.setPerson_type(null);
        filter.setDocument_type(null);
        filter.setDocument_number(null);
        filter.setStates("A");

        // Llamar al método getFilters para obtener la lista de resultados
        List<Economy> economies = economyService.getFilters(filter);

        // Imprimir los resultados en formato de tabla
        if (economies.isEmpty()) {
            System.out.println("No se encontraron resultados.");
        } else {
            System.out.println("Resultados encontrados:");
            System.out.println("--------------------------------------------------------------");
            System.out.printf("%-10s | %-20s | %-20s | %-20s | %-10s%n", "ID", "Tipo de Economía", "Número de Operación",
                    "Tipo de Persona", "Estados");
            System.out.println("--------------------------------------------------------------");
            for (Economy economy : economies) {
                System.out.printf("%-10s | %-20s | %-20s | %-20s | %-10s%n",
                        economy.getEconomy_id(), economy.getEconomy_type(), economy.getNumber_operation(),
                        economy.getPerson_type(), economy.getStates());
            }
            System.out.println("--------------------------------------------------------------");
        }
    }
}
