package pe.edu.vallegrande.app.prueba.student;

import pe.edu.vallegrande.app.model.Student;
import pe.edu.vallegrande.app.service.CrudStudentService;

import java.util.List;

public class getFiltersTest {
    public static void main(String[] args) {
        // Crear una instancia de CrudStudentService
        CrudStudentService studentService = new CrudStudentService();

        // Crear un objeto Student con los valores de los filtros
        Student filter = new Student();
        filter.setNames(null);
        filter.setSurname(null);
        filter.setDocument_number(null);
        //filter.setDegree_section(null);
        filter.setCarrera(null);
        filter.setCiclo(null);
        filter.setStates("A");

        // Llamar al método getFilters para obtener la lista de resultados
        List<Student> students = studentService.getFilters(filter);

        // Imprimir los resultados en formato de tabla
        if (students.isEmpty()) {
            System.out.println("No se encontraron resultados.");
        } else {
            System.out.println("Resultados encontrados:");
            System.out.println("--------------------------------------------------------------");
            System.out.printf("%-10s | %-20s | %-20s | %-20s | %-20s | %-10s%n", "ID", "Nombres", "Apellido", "Número de documento", "Sección", "Estados");
            System.out.println("--------------------------------------------------------------");
            for (Student student : students) {
                System.out.printf("%-10s | %-20s | %-20s | %-20s | %-20s | %-10s%n",
                        student.getStudent_id(), student.getNames(), student.getSurname(),
                        student.getDocument_type(), student.getCarrera(), student.getCiclo(), student.getStates());
            }
            System.out.println("--------------------------------------------------------------");
        }
    }
}
