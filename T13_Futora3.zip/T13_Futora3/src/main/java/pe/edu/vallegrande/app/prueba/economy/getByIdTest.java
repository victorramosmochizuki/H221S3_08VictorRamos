package pe.edu.vallegrande.app.prueba.economy;

import pe.edu.vallegrande.app.model.Economy;
import pe.edu.vallegrande.app.service.CrudEconomyService;

public class getByIdTest {
    public static void main(String[] args) {
        // ID del registro de Economy a buscar
        int economy_id = 3; // Reemplaza con el ID del registro de Economy que deseas buscar
        
        // Crear una instancia de CrudEconomyService
        CrudEconomyService economyService = new CrudEconomyService();
        
        // Llamar al método getById para obtener el registro de Economy por su ID
        Economy economy = economyService.getById(economy_id);
        
        // Imprimir el registro de Economy obtenido
        if (economy != null) {
            System.out.println("Registro de Economy encontrado:");
            System.out.println(economy);
        } else {
            System.out.println("No se encontró ningún registro de Economy con el ID proporcionado: " + economy_id);
        }
    }
}
