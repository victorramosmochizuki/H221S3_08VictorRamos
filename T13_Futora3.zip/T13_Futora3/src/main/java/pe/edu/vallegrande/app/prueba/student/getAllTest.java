package pe.edu.vallegrande.app.prueba.student;

import pe.edu.vallegrande.app.model.Student;
import pe.edu.vallegrande.app.service.CrudStudentService;

import java.util.List;

public class getAllTest {
    public static void main(String[] args) {
        // Crear instancia del servicio
        CrudStudentService studentService = new CrudStudentService();

        // Obtener todos los estudiantes
        List<Student> students = studentService.getAll();

        // Mostrar los estudiantes
        if (students.isEmpty()) {
            System.out.println("No se encontraron estudiantes.");
        } else {
            System.out.println("Lista de estudiantes:");
            for (Student student : students) {
                System.out.println(student);
            }
        }
    }
}
