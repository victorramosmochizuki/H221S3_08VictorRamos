package pe.edu.vallegrande.app.prueba.attorney;

import pe.edu.vallegrande.app.model.Attorney;
import pe.edu.vallegrande.app.service.CrudAttorneyService;

import java.util.List;

public class getFiltersTest {
    public static void main(String[] args) {
        // Crear una instancia de CrudAttorneyService
        CrudAttorneyService attorneyService = new CrudAttorneyService();

        // Crear un objeto Attorney con los valores de los filtros
        Attorney filter = new Attorney();
        filter.setNames(null);
        filter.setSurname(null);
        filter.setDocument_number(null);
        filter.setStates("A");

        // Llamar al método getFilters para obtener la lista de resultados
        List<Attorney> attorneys = attorneyService.getFilters(filter);

        // Imprimir los resultados en formato de tabla
        if (attorneys.isEmpty()) {
            System.out.println("No se encontraron resultados.");
        } else {
            System.out.println("Resultados encontrados:");
            System.out.println("--------------------------------------------------------------");
            System.out.printf("%-10s | %-20s | %-20s | %-20s | %-10s%n", "ID", "Nombres", "Apellido", "Tipo de documento", "Estados");
            System.out.println("--------------------------------------------------------------");
            for (Attorney attorney : attorneys) {
                System.out.printf("%-10s | %-20s | %-20s | %-20s | %-10s%n",
                        attorney.getAttorney_id(), attorney.getNames(), attorney.getSurname(),
                        attorney.getDocument_type(), attorney.getStates());
            }
            System.out.println("--------------------------------------------------------------");
        }
    }
}
