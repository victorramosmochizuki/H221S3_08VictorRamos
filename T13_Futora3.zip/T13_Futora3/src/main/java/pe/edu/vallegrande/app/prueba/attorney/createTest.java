package pe.edu.vallegrande.app.prueba.attorney;

import pe.edu.vallegrande.app.model.Attorney;
import pe.edu.vallegrande.app.service.CrudAttorneyService;

public class createTest {
    public static void main(String[] args) {
        // Crear un nuevo objeto Attorney
        Attorney attorney = new Attorney();
        
        // Establecer las propiedades del objeto attorney
        attorney.setNames("John");
        attorney.setSurname("Doe");
        attorney.setDocument_type("DNI");
        attorney.setDocument_number("12451265");
        attorney.setCellphone("123456789");
        attorney.setEmail("johndoe@example.com");
        
        // Crear una instancia de CrudAttorneyService
        CrudAttorneyService attorneyService = new CrudAttorneyService();
        
        // Llamar al método create para crear el apoderado
        attorneyService.create(attorney);
        
        // Imprimir un mensaje de éxito
        System.out.println("Apoderado creado exitosamente.");
    }
}
