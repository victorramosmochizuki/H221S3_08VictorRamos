package pe.edu.vallegrande.app.prueba.attorney;

import pe.edu.vallegrande.app.model.Attorney;
import pe.edu.vallegrande.app.service.CrudAttorneyService;

import java.util.List;

public class getAllTest {

    public static void main(String[] args) {
        // Crear una instancia del servicio
        CrudAttorneyService attorneyService = new CrudAttorneyService();

        // Obtener todos los registros
        List<Attorney> attorneys = attorneyService.getAll();

        // Verificar si se obtuvieron registros
        if (attorneys.isEmpty()) {
            System.out.println("No se encontraron registros de apoderado.");
        } else {
            System.out.println("Registros de apoderado encontrados:");
            for (Attorney attorney : attorneys) {
                System.out.println(attorney);
            }
        }
    }
}
