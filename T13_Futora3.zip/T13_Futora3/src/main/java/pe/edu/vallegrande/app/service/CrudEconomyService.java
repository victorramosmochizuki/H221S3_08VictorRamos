package pe.edu.vallegrande.app.service;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import pe.edu.vallegrande.app.db.AccesoDB;
import pe.edu.vallegrande.app.model.Economy;
import pe.edu.vallegrande.app.service.spec.CrudServiceSpec;
import pe.edu.vallegrande.app.service.spec.RowMapper;

public class CrudEconomyService implements CrudServiceSpec<Economy>, RowMapper<Economy> {

	// Definiendo consultas
	private final String SQL_SELECT_BASE = "SELECT economy_id, modality, economy_type, number_operation, person_type, document_type, document_number, descriptions, amount, total_incomes, total_expenses, diferencity, states, date_hour FROM ECONOMY";
	private final String SQL_CREATE = "INSERT INTO ECONOMY (modality, economy_type, number_operation, person_type, document_type, document_number, descriptions, amount) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
	private final String SQL_UPDATE = "UPDATE ECONOMY SET modality=?, economy_type=?, number_operation=?, person_type=?, document_type=?, document_number=?, descriptions=?, amount=? WHERE economy_id=?";
	private final String SQL_STATES = "UPDATE ECONOMY SET states=? WHERE economy_id=?";

	// Mapeado de listas
	@Override
	public Economy mapRow(ResultSet rs) throws SQLException {
		Economy bean = new Economy();

		bean.setEconomy_id(rs.getInt("economy_id"));
		bean.setModality(rs.getString("modality"));
		bean.setEconomy_type(rs.getString("economy_type"));
		bean.setNumber_operation(rs.getString("number_operation"));
		bean.setPerson_type(rs.getString("person_type"));
		bean.setDocument_type(rs.getString("document_type"));
		bean.setDocument_number(rs.getString("document_number"));
		bean.setDescriptions(rs.getString("descriptions"));
		bean.setAmount(rs.getBigDecimal("amount"));
		bean.setTotal_incomes(rs.getBigDecimal("total_incomes"));
		bean.setTotal_expenses(rs.getBigDecimal("total_expenses"));
		bean.setDiferencity(rs.getBigDecimal("diferencity"));
		bean.setStates(rs.getString("states"));
		bean.setDate_hour(rs.getDate("date_hour"));

		return bean;
	}

	// Creación de registros
	@Override
	public void create(Economy bean) {
		try (Connection connection = AccesoDB.getConnection();
				PreparedStatement statement = connection.prepareStatement(SQL_CREATE,
						Statement.RETURN_GENERATED_KEYS)) {

			statement.setString(1, bean.getModality());
			statement.setString(2, bean.getEconomy_type());
			statement.setString(3, bean.getNumber_operation());
			statement.setString(4, bean.getPerson_type());
			statement.setString(5, bean.getDocument_type());
			statement.setString(6, bean.getDocument_number());
			statement.setString(7, bean.getDescriptions());
			statement.setBigDecimal(8, bean.getAmount());

			int rowsAffected = statement.executeUpdate();

			if (rowsAffected > 0) {
				ResultSet generatedKeys = statement.getGeneratedKeys();
				if (generatedKeys.next()) {
					int generatedId = generatedKeys.getInt(1);
					bean.setEconomy_id(generatedId);
				}

				// Actualizar total_incomes y total_expenses
				String updateIncomesQuery = "UPDATE ECONOMY SET total_incomes = (SELECT SUM(amount) FROM ECONOMY WHERE economy_type = 'IN' AND states = 'A') WHERE states = 'A'";
				connection.prepareStatement(updateIncomesQuery).executeUpdate();

				String updateExpensesQuery = "UPDATE ECONOMY SET total_expenses = (SELECT SUM(amount) FROM ECONOMY WHERE economy_type = 'EG' AND states = 'A') WHERE states = 'A'";
				connection.prepareStatement(updateExpensesQuery).executeUpdate();

				String updateDiferencityQuery = "UPDATE ECONOMY SET diferencity = total_incomes - total_expenses WHERE states = 'A'";
				connection.prepareStatement(updateDiferencityQuery).executeUpdate();

				System.out.println("Número de Documento: " + bean.getDocument_number());
				System.out.println("Registro insertado: " + bean);
				System.out.println("-------------------------------------------");
			} else {
				System.out.println("Error al crear el registro");
			}

		} catch (SQLException e) {
			e.printStackTrace();
			// Manejar excepción
		}
	}

	// Reactivación de registros
	@Override
	public void reactivate(int id) {
		try (Connection connection = AccesoDB.getConnection();
				PreparedStatement statement = connection.prepareStatement(SQL_STATES)) {

			statement.setString(1, "A");
			statement.setInt(2, id);

			int rowsAffected = statement.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Registro de Economy reactivado con ID: " + id);
			} else {
				System.out.println("No se encontró ningún registro de Economy con el ID proporcionado: " + id);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			// Manejar excepción
		}
	}

	// Actualización de registros
	@Override
	public void update(Economy bean) {
		try (Connection connection = AccesoDB.getConnection();
				PreparedStatement statement = connection.prepareStatement(SQL_UPDATE)) {

			statement.setString(1, bean.getModality());
			statement.setString(2, bean.getEconomy_type());
			statement.setString(3, bean.getNumber_operation());
			statement.setString(4, bean.getPerson_type());
			statement.setString(5, bean.getDocument_type());
			statement.setString(6, bean.getDocument_number());
			statement.setString(7, bean.getDescriptions());
			statement.setBigDecimal(8, bean.getAmount());
			statement.setInt(9, bean.getEconomy_id());

			int rowsAffected = statement.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Registro de Economy actualizado con ID: " + bean.getEconomy_id());
			} else {
				System.out.println(
						"No se encontró ningún registro de Economy con el ID proporcionado: " + bean.getEconomy_id());
			}

		} catch (SQLException e) {
			e.printStackTrace();
			// Manejar excepción
		}
	}

	// Eliminación lógica de registros
	@Override
	public void softDelete(int id) {
		try (Connection connection = AccesoDB.getConnection();
				PreparedStatement statement = connection.prepareStatement(SQL_STATES)) {

			statement.setString(1, "I");
			statement.setInt(2, id);

			int rowsAffected = statement.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Registro de Economy eliminado suavemente con ID: " + id);
			} else {
				System.out.println("No se encontró ningún registro de Economy con el ID proporcionado: " + id);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			// Manejar excepción
		}
	}

	// Mostrar todo
	@Override
	public List<Economy> getAll() {
		List<Economy> economyList = new ArrayList<>();

		try (Connection connection = AccesoDB.getConnection();
				Statement statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery(SQL_SELECT_BASE)) {

			while (resultSet.next()) {
				Economy economy = new Economy();
				economy.setEconomy_id(resultSet.getInt("economy_id"));
				economy.setModality(resultSet.getString("modality"));
				economy.setEconomy_type(resultSet.getString("economy_type"));
				economy.setNumber_operation(resultSet.getString("number_operation").trim());
				economy.setPerson_type(resultSet.getString("person_type"));
				economy.setDocument_type(resultSet.getString("document_type"));
				economy.setDocument_number(resultSet.getString("document_number"));
				economy.setDescriptions(resultSet.getString("descriptions"));
				economy.setAmount(resultSet.getBigDecimal("amount"));
				economy.setTotal_incomes(resultSet.getBigDecimal("total_incomes"));
				economy.setTotal_expenses(resultSet.getBigDecimal("total_expenses"));
				economy.setDiferencity(resultSet.getBigDecimal("diferencity"));
				economy.setStates(resultSet.getString("states"));
				economy.setDate_hour(resultSet.getDate("date_hour"));

				economyList.add(economy);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			// Manejar excepción
		}

		return economyList;
	}

	// Buscar por id
	@Override
	public Economy getById(int id) {
		Economy economy = null;

		try (Connection connection = AccesoDB.getConnection();
				PreparedStatement statement = connection.prepareStatement(SQL_SELECT_BASE + " WHERE economy_id = ?")) {

			statement.setInt(1, id);
			ResultSet resultSet = statement.executeQuery();

			if (resultSet.next()) {
				int economyId = resultSet.getInt("economy_id");
				String modality = resultSet.getString("modality");
				String economyType = resultSet.getString("economy_type");
				String numberOperation = resultSet.getString("number_operation").trim();
				String personType = resultSet.getString("person_type");
				String documentType = resultSet.getString("document_type");
				String documentNumber = resultSet.getString("document_number");
				String descriptions = resultSet.getString("descriptions");
				BigDecimal amount = resultSet.getBigDecimal("amount");
				BigDecimal totalIncomes = resultSet.getBigDecimal("total_incomes");
				BigDecimal totalExpenses = resultSet.getBigDecimal("total_expenses");
				BigDecimal diferencias = resultSet.getBigDecimal("diferencias");
				String states = resultSet.getString("states");
				Date dateHour = resultSet.getDate("date_hour");

				economy = new Economy(economyId, modality, economyType, numberOperation, personType, documentType,
						documentNumber, descriptions, amount, totalIncomes, totalExpenses, diferencias, states,
						dateHour);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return economy;
	}

	// Buscar por filtros
	@Override
	public List<Economy> getFilters(Economy bean) {
		// Variables
		Connection connection = null;
		List<Economy> lista = new ArrayList<>();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		Economy item;
		String sql;
		String economy_type;
		String number_operation;
		String document_number;
		String states;
		// Preparar los datos
		economy_type = "%" + UtilService.setStringVacio(bean.getEconomy_type()) + "%";
		number_operation = "%" + UtilService.setStringVacio(bean.getNumber_operation()).trim() + "%";
		document_number = "%" + UtilService.setStringVacio(bean.getDocument_number()) + "%";
		states = "%" + UtilService.setStringVacio(bean.getStates()) + "%";
		// Proceso
		try {
			// Conexión
			connection = AccesoDB.getConnection();
			// Consulta
			sql = SQL_SELECT_BASE + " WHERE economy_type LIKE ? AND number_operation LIKE ? "
					+ "AND document_number LIKE ? AND states LIKE ?";
			statement = connection.prepareStatement(sql);
			statement.setString(1, economy_type);
			statement.setString(2, number_operation);
			statement.setString(3, document_number);
			statement.setString(4, states);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				item = mapRow(resultSet);
				lista.add(item);
			}
		} catch (SQLException e) {
			throw new RuntimeException(e.getMessage());
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return lista;
	}
}
