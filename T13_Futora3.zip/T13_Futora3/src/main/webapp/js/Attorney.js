// Constantes del CRUD
const ACCION_NUEVO = "NUEVO";
const ACCION_EDITAR = "EDITAR";
const ACCION_ELIMINAR = "ELIMINAR";
const ACCION_REACTIVAR = "REACTIVAR";

// Arreglo de registros
let arreglo = [];

// Acceder a los controles
let btnBuscar = document.getElementById("btnBuscar");
let btnNuevo = document.getElementById("btnNuevo");
let btnProcesar = document.getElementById("btnProcesar");

// Programar los controles
btnBuscar.addEventListener("click", fnBtnBuscar);
btnNuevo.addEventListener("click", fnBtnNuevo);
btnProcesar.addEventListener("click", fnBtnProcesar);

// Funcion fnEditar
function fnEditar(attorney_id) {
	// Preparando el formulario
	document.getElementById("tituloRegistro").innerHTML =
		ACCION_EDITAR + " REGISTRO";
	document.getElementById("accion").value = ACCION_EDITAR;

	// Imprimir el arreglo antes de cargar los datos
	console.log("Arreglo antes de cargar los datos:");
	console.log(arreglo);

	fnCargarForm(attorney_id);

	// Mostrar formulario
	document.getElementById("divResultado").style.display = "none";
	document.getElementById("divRegistro").style.display = "block";
}


// Funcion fnEliminar
function fnEliminar(attorney_id) {
	// Mostrar ventana de confirmación
	if (confirm("¿Estás seguro de que deseas eliminar este apoderado?")) {
		// Preparar la URL
		let url = "AttorneyProcesar?accion=" + encodeURIComponent("ELIMINAR") + "&attorney_id=" + encodeURIComponent(attorney_id);

		// Realizar la llamada AJAX
		let xhttp = new XMLHttpRequest();
		xhttp.open("POST", url, true);
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				// Mostrar mensaje de éxito y volver a realizar la búsqueda
				alert("Registro eliminado exitosamente.");
				fnBtnBuscar();
			}
		};
		xhttp.send();
	}
}

// Función para reactivar
function fnReactivar(attorney_id) {
	// Confirmar la reactivación
	if (confirm("¿Estás seguro de que deseas reactivar este apoderado?")) {
		// Preparar la URL
		let url = "AttorneyProcesar?accion=" + encodeURIComponent("REACTIVAR") + "&attorney_id=" + encodeURIComponent(attorney_id);

		// Realizar la llamada AJAX
		let xhttp = new XMLHttpRequest();
		xhttp.open("POST", url, true);
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				// Mostrar mensaje de éxito y volver a realizar la búsqueda
				alert("Apoderado reactivado exitosamente.");
				fnBtnBuscar();
			}
		};
		xhttp.send();
	}
}

// Funcion fnBtnProcesar
function fnBtnProcesar() {
	// Preparar los datos
	let accion = document.getElementById("accion").value;
	let attorney_id = document.getElementById("frmAttorney_id").value;
	let names = document.getElementById("frmNames").value;
	let surname = document.getElementById("frmSurname").value;
	let document_type = document.getElementById("frmDocument_type").value;
	let document_number = document.getElementById("frmDocument_number").value;
	let cellphone = document.getElementById("frmCellphone").value;
	let email = document.getElementById("frmEmail").value;
	let states = document.getElementById("frmStates").value;

	// Validar que los campos requeridos no estén vacíos
	if (names.trim() === "" || surname.trim() === "" || document_type.trim() === "" || document_number.trim() === "" || cellphone.trim() === "" || email.trim() === "") {
		alert("Por favor, complete los campos obligatorios.");
		return;
	}

	console.log("Acción: " + accion);
	console.log("Attorney ID: " + attorney_id);
	console.log("Names: " + names);
	console.log("Surname: " + surname);
	console.log("Document Type: " + document_type);
	console.log("Document Number: " + document_number);
	console.log("Cellphone: " + cellphone);
	console.log("Email: " + email);
	console.log("States: " + states);

	// Preparar los datos a enviar
	let datos =
		"accion=" + encodeURIComponent(accion) +
		"&attorney_id=" + encodeURIComponent(attorney_id) +
		"&names=" + encodeURIComponent(names) +
		"&surname=" + encodeURIComponent(surname) +
		"&document_type=" + encodeURIComponent(document_type) +
		"&document_number=" + encodeURIComponent(document_number) +
		"&cellphone=" + encodeURIComponent(cellphone) +
		"&email=" + encodeURIComponent(email) +
		"&states=" + encodeURIComponent(states);

	// Enviar la solicitud con AJAX
	let xhr = new XMLHttpRequest();
	xhr.open("POST", "AttorneyProcesar", true);
	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xhr.onreadystatechange = function() {
		if (xhr.readyState === 4 && xhr.status === 200) {
			// La solicitud se completó correctamente
			console.log(xhr.responseText);
			alert(xhr.responseText);

			// Actualizar la interfaz de usuario después de la respuesta exitosa
			if (accion === ACCION_NUEVO || accion === ACCION_EDITAR) {
				// Actualizar la tabla de registros
				fnBtnBuscar();
			} else if (accion === ACCION_ELIMINAR || accion === ACCION_REACTIVAR) {
				// Actualizar la tabla de registros y limpiar el formulario
				fnBtnBuscar();
				fnLimpiarFormulario();
			}
		}
	};
	xhr.onreadystatechange = function() {
		if (xhr.readyState === 4 && xhr.status === 200) {
			// La solicitud se completó correctamente
			console.log(xhr.responseText);
			alert(xhr.responseText);

			// Actualizar la interfaz de usuario después de la respuesta exitosa
			if (accion === ACCION_NUEVO || accion === ACCION_EDITAR) {
				// Actualizar la tabla de registros
				fnBtnBuscar();
				// Limpiar el formulario
				fnLimpiarFormulario();
			} else if (accion === ACCION_ELIMINAR || accion === ACCION_REACTIVAR) {
				// Actualizar la tabla de registros y limpiar el formulario
				fnBtnBuscar();
				fnLimpiarFormulario();
			}
		}
	};
	xhr.send(datos);

	// Llamar automáticamente a la función fnBtnBuscar después de procesar
	fnBtnBuscar();
}

// Funcion fnBtnNuevo
function fnBtnNuevo() {
	// Preparando el formulario
	document.getElementById("tituloRegistro").innerHTML =
		ACCION_NUEVO + " REGISTRO";
	document.getElementById("accion").value = ACCION_NUEVO;
	// Mostrar formulario
	document.getElementById("divResultado").style.display = "none";
	document.getElementById("divRegistro").style.display = "block";
}

// Realiza la búsqueda
function fnBtnBuscar() {
	// Datos
	let names = document.getElementById("names").value;
	let surname = document.getElementById("surname").value;
	let document_type = document.getElementById("document_type").value;
	let states = document.getElementById("states").value;

	// Establecer el valor predeterminado "A" si el campo de estado está vacío
	if (states.trim() === "") {
		states = "A";
		document.getElementById("states").value = states;
	}
	
	// Preparar la URL
	let url =
		"AttorneyBuscar2?names=" +
		encodeURIComponent(names) +
		"&surname=" +
		encodeURIComponent(surname) +
		"&document_type=" +
		encodeURIComponent(document_type) +
		"&states=" +
		encodeURIComponent(states);

	// Realizar la llamada AJAX
	let xhttp = new XMLHttpRequest();
	xhttp.open("GET", url, true);
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			let respuesta = xhttp.responseText;
			let arregloRespuesta = [];
			if (respuesta && respuesta.trim() !== "") {
				arregloRespuesta = JSON.parse(respuesta);
			}
			arreglo = arregloRespuesta; // Actualizar el arreglo global con la respuesta
			let AttorneyTable = "";
			arreglo.forEach(function(item) {
				AttorneyTable += "<tr>";
				AttorneyTable += "<td>" + item.attorney_id + "</td>";
				AttorneyTable += "<td>" + item.names + "</td>";
				AttorneyTable += "<td>" + item.surname + "</td>";
				AttorneyTable += "<td>" + item.document_type + "</td>";
				AttorneyTable += "<td>" + item.document_number + "</td>";
				AttorneyTable += "<td>" + item.cellphone + "</td>";
				AttorneyTable += "<td>" + item.email + "</td>";
				AttorneyTable += "<td>" + item.states + "</td>";
				AttorneyTable += "<td>";
				if (item.states === "A") {
					AttorneyTable +=
						"<a href='javascript:void(0);' onclick='fnEditar(\"" + item.attorney_id + "\");'>Editar</a> ";
					AttorneyTable +=
						"<a href='javascript:void(0);' onclick='fnEliminar(\"" + item.attorney_id + "\");'>Eliminar</a>";
				} else if (item.states === "I") {
					AttorneyTable +=
						"<a href='javascript:void(0);' onclick='fnReactivar(\"" + item.attorney_id + "\");'>Reactivar</a>";
				}
				AttorneyTable += "</td>";
				AttorneyTable += "</tr>";
			});
			document.getElementById("AttorneyTable").innerHTML = AttorneyTable;
			// Mostrar formulario
			document.getElementById("divResultado").style.display = "block";
			document.getElementById("divRegistro").style.display = "none";
		}
	};
	xhttp.send();
}

// Carga el formulario
function fnCargarForm(attorney_id) {
	let parsedAttorney_id = parseInt(attorney_id); // Convertir a entero

	let foundItem = arreglo.find(function(item) {
		return item.attorney_id === parsedAttorney_id;
	});

	if (foundItem) {
		document.getElementById("frmAttorney_id").value = foundItem.attorney_id;
		document.getElementById("frmNames").value = foundItem.names;
		document.getElementById("frmSurname").value = foundItem.surname;
		document.getElementById("frmDocument_type").value = foundItem.document_type;
		document.getElementById("frmDocument_number").value = foundItem.document_number;
		document.getElementById("frmCellphone").value = foundItem.cellphone;
		document.getElementById("frmEmail").value = foundItem.email;
		document.getElementById("frmStates").value = foundItem.states;
	}
}


// Limpiar el formulario
function fnLimpiarFormulario() {
	document.getElementById("frmAttorney_id").value = "";
	document.getElementById("frmNames").value = "";
	document.getElementById("frmSurname").value = "";
	document.getElementById("frmDocument_type").value = "";
	document.getElementById("frmDocument_number").value = "";
	document.getElementById("frmCellphone").value = "";
	document.getElementById("frmEmail").value = "";
	document.getElementById("frmStates").value = "";
}

// Validaciones
$(document).ready(function() {
	// Validación del formulario al enviar
	$("#btnProcesar").click(function() {
		if ($("#attorneyForm")[0].checkValidity()) {
			// Realizar la llamada AJAX
			// ...
		} else {
			$("#attorneyForm")[0].classList.add('was-validated');
		}
	});
});

function validateForm() {
	var cellphone = document.getElementById('frmCellphone').value;
	var email = document.getElementById('frmEmail').value;

	var valid = true;

	if (cellphone.length !== 9 || isNaN(cellphone)) {
		document.getElementById('frmCellphone').classList.add('is-invalid');
		valid = false;
	} else {
		document.getElementById('frmCellphone').classList.remove('is-invalid');
	}

	if (email.indexOf('@') === -1 || email.indexOf('.') === -1) {
		document.getElementById('frmEmail').classList.add('is-invalid');
		valid = false;
	} else {
		document.getElementById('frmEmail').classList.remove('is-invalid');
	}

	return valid;
}