// Constantes del CRUD
const ACCION_NUEVO = "NUEVO";
const ACCION_EDITAR = "EDITAR";
const ACCION_ELIMINAR = "ELIMINAR";
const ACCION_REACTIVAR = "REACTIVAR";

// Arreglo de registros
let arreglo = [];

// Acceder a los controles
let btnBuscar = document.getElementById("btnBuscar");
let btnNuevo = document.getElementById("btnNuevo");
let btnProcesar = document.getElementById("btnProcesar");

// Programar los controles
btnBuscar.addEventListener("click", fnBtnBuscar);
btnNuevo.addEventListener("click", fnBtnNuevo);
btnProcesar.addEventListener("click", fnBtnProcesar);

// Funcion fnEditar
function fnEditar(student_id) {
	// Preparando el formulario
	document.getElementById("tituloRegistro").innerHTML =
		ACCION_EDITAR + " REGISTRO";
	document.getElementById("accion").value = ACCION_EDITAR;

	// Imprimir el arreglo antes de cargar los datos
	console.log("Arreglo antes de cargar los datos:");
	console.log(arreglo);

	fnCargarForm(student_id);

	// Mostrar formulario
	document.getElementById("divResultado").style.display = "none";
	document.getElementById("divRegistro").style.display = "block";
}


// Funcion fnEliminar
function fnEliminar(student_id) {
	// Mostrar ventana de confirmación
	if (confirm("¿Estás seguro de que deseas eliminar este apoderado?")) {
		// Preparar la URL
		let url = "StudentProcesar?accion=" + encodeURIComponent("ELIMINAR") + "&student_id=" + encodeURIComponent(student_id);

		// Realizar la llamada AJAX
		let xhttp = new XMLHttpRequest();
		xhttp.open("POST", url, true);
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				// Mostrar mensaje de éxito y volver a realizar la búsqueda
				alert("Registro eliminado exitosamente.");
				fnBtnBuscar();
			}
		};
		xhttp.send();
	}
}

// Función para reactivar
function fnReactivar(student_id) {
	// Confirmar la reactivación
	if (confirm("¿Estás seguro de que deseas reactivar este estudiante?")) {
		// Preparar la URL
		let url = "StudentProcesar?accion=" + encodeURIComponent("REACTIVAR") + "&student_id=" + encodeURIComponent(student_id);

		// Realizar la llamada AJAX
		let xhttp = new XMLHttpRequest();
		xhttp.open("POST", url, true);
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				// Mostrar mensaje de éxito y volver a realizar la búsqueda
				alert("Estudiante reactivado exitosamente.");
				fnBtnBuscar();
			}
		};
		xhttp.send();
	}
}

// Funcion fnBtnProcesar
function fnBtnProcesar() {
	// Preparar los datos
	let accion = document.getElementById("accion").value;
	let student_id = document.getElementById("frmStudent_id").value;
	let names = document.getElementById("frmNames").value;
	let surname = document.getElementById("frmSurname").value;
	let document_type = document.getElementById("frmDocument_type").value;
	let document_number = document.getElementById("frmDocument_number").value;
	let degree_section = document.getElementById("frmDegree_section").value;
	let cellphone = document.getElementById("frmCellphone").value;
	let email = document.getElementById("frmEmail").value;
	let father_document = document.getElementById("frmFather_document").value;
	let mother_document = document.getElementById("frmMother_document").value;
	let states = document.getElementById("frmStates").value;

	// Validar que los campos requeridos no estén vacíos
	if (names.trim() === "" || surname.trim() === "" || document_type.trim() === "" || document_number.trim() === "" || degree_section.trim() === "" || cellphone.trim() === "" || email.trim() === "" || father_document.trim() === "" || mother_document.trim() === "") {
		alert("Por favor, complete los campos obligatorios.");
		return;
	}

	console.log("Acción: " + accion);
	console.log("Student ID: " + student_id);
	console.log("Names: " + names);
	console.log("Surname: " + surname);
	console.log("Document Type: " + document_type);
	console.log("Document Number: " + document_number);
	console.log("Degree Section: " + degree_section);
	console.log("Cellphone: " + cellphone);
	console.log("Email: " + email);
	console.log("Father Document: " + father_document);
	console.log("Mother Document: " + mother_document);
	console.log("States: " + states);

	// Preparar los datos a enviar
	let datos =
		"accion=" + encodeURIComponent(accion) +
		"&student_id=" + encodeURIComponent(student_id) +
		"&names=" + encodeURIComponent(names) +
		"&surname=" + encodeURIComponent(surname) +
		"&document_type=" + encodeURIComponent(document_type) +
		"&document_number=" + encodeURIComponent(document_number) +
		"&degree_section=" + encodeURIComponent(degree_section) +
		"&cellphone=" + encodeURIComponent(cellphone) +
		"&email=" + encodeURIComponent(email) +
		"&father_document=" + encodeURIComponent(father_document) +
		"&mother_document=" + encodeURIComponent(mother_document) +
		"&states=" + encodeURIComponent(states);

	// Enviar la solicitud con AJAX
	let xhr = new XMLHttpRequest();
	xhr.open("POST", "StudentProcesar", true);
	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xhr.onreadystatechange = function() {
		if (xhr.readyState === 4 && xhr.status === 200) {
			// La solicitud se completó correctamente
			console.log(xhr.responseText);
			alert(xhr.responseText);

			// Actualizar la interfaz de usuario después de la respuesta exitosa
			if (accion === ACCION_NUEVO || accion === ACCION_EDITAR) {
				// Actualizar la tabla de registros
				fnBtnBuscar();
			} else if (accion === ACCION_ELIMINAR || accion === ACCION_REACTIVAR) {
				// Actualizar la tabla de registros y limpiar el formulario
				fnBtnBuscar();
				fnLimpiarFormulario();
			}
		}
	};
	xhr.onreadystatechange = function() {
		if (xhr.readyState === 4 && xhr.status === 200) {
			// La solicitud se completó correctamente
			console.log(xhr.responseText);
			alert(xhr.responseText);

			// Actualizar la interfaz de usuario después de la respuesta exitosa
			if (accion === ACCION_NUEVO || accion === ACCION_EDITAR) {
				// Actualizar la tabla de registros
				fnBtnBuscar();
				// Limpiar el formulario
				fnLimpiarFormulario();
			} else if (accion === ACCION_ELIMINAR || accion === ACCION_REACTIVAR) {
				// Actualizar la tabla de registros y limpiar el formulario
				fnBtnBuscar();
				fnLimpiarFormulario();
			}
		}
	};
	xhr.send(datos);

	// Llamar automáticamente a la función fnBtnBuscar después de procesar
	fnBtnBuscar();
}

// Funcion fnBtnNuevo
function fnBtnNuevo() {
	// Preparando el formulario
	document.getElementById("tituloRegistro").innerHTML =
		ACCION_NUEVO + " REGISTRO";
	document.getElementById("accion").value = ACCION_NUEVO;
	// Mostrar formulario
	document.getElementById("divResultado").style.display = "none";
	document.getElementById("divRegistro").style.display = "block";
}

// Realiza la búsqueda
function fnBtnBuscar() {
	// Datos
	let names = document.getElementById("names").value;
	let surname = document.getElementById("surname").value;
	let document_type = document.getElementById("document_type").value;
	let degree_section = document.getElementById("degree_section").value;
	let states = document.getElementById("states").value;

	// Preparar la URL
	let url =
		"StudentBuscar2?names=" +
		encodeURIComponent(names) +
		"&surname=" +
		encodeURIComponent(surname) +
		"&document_type=" +
		encodeURIComponent(document_type) +
		"&degree_section=" +
		encodeURIComponent(degree_section) +
		"&states=" +
		encodeURIComponent(states);

	// Realizar la llamada AJAX
	let xhttp = new XMLHttpRequest();
	xhttp.open("GET", url, true);
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			let respuesta = xhttp.responseText;
			let arregloRespuesta = [];
			if (respuesta && respuesta.trim() !== "") {
				arregloRespuesta = JSON.parse(respuesta);
			}
			arreglo = arregloRespuesta; // Actualizar el arreglo global con la respuesta
			let StudentTable = "";
			arreglo.forEach(function(item) {
				StudentTable += "<tr>";
				StudentTable += "<td>" + item.student_id + "</td>";
				StudentTable += "<td>" + item.names + "</td>";
				StudentTable += "<td>" + item.surname + "</td>";
				StudentTable += "<td>" + item.document_type + "</td>";
				StudentTable += "<td>" + item.document_number + "</td>";
				StudentTable += "<td>" + item.degree_section + "</td>";
				StudentTable += "<td>" + item.cellphone + "</td>";
				StudentTable += "<td>" + item.email + "</td>";
				StudentTable += "<td>" + item.father_document + "</td>";
				StudentTable += "<td>" + item.mother_document + "</td>";
				StudentTable += "<td>" + item.states + "</td>";
				StudentTable += "<td>";
				if (item.states === "A") {
					StudentTable +=
						"<a href='javascript:void(0);' onclick='fnEditar(\"" + item.student_id + "\");'>Editar</a> ";
					StudentTable +=
						"<a href='javascript:void(0);' onclick='fnEliminar(\"" + item.student_id + "\");'>Eliminar</a>";
				} else if (item.states === "I") {
					StudentTable +=
						"<a href='javascript:void(0);' onclick='fnReactivar(\"" + item.student_id + "\");'>Reactivar</a>";
				}
				StudentTable += "</td>";
				StudentTable += "</tr>";
			});
			document.getElementById("StudentTable").innerHTML = StudentTable;
			// Mostrar formulario
			document.getElementById("divResultado").style.display = "block";
			document.getElementById("divRegistro").style.display = "none";
		}
	};
	xhttp.send();
}

// Carga el formulario
function fnCargarForm(student_id) {
	let parsedStudent_id = parseInt(student_id); // Convertir a entero

	let foundItem = arreglo.find(function(item) {
		return item.student_id === parsedStudent_id;
	});

	if (foundItem) {
		document.getElementById("frmStudent_id").value = foundItem.student_id;
		document.getElementById("frmNames").value = foundItem.names;
		document.getElementById("frmSurname").value = foundItem.surname;
		document.getElementById("frmDocument_type").value = foundItem.document_type;
		document.getElementById("frmDocument_number").value = foundItem.document_number;
		document.getElementById("frmDegree_section").value = foundItem.degree_section;
		document.getElementById("frmCellphone").value = foundItem.cellphone;
		document.getElementById("frmEmail").value = foundItem.email;
		document.getElementById("frmFather_document ").value = foundItem.father_document;
		document.getElementById("frmMother_document").value = foundItem.mother_document;
		document.getElementById("frmStates").value = foundItem.states;
	}
}


// Limpiar el formulario
function fnLimpiarFormulario() {
	document.getElementById("frmStudent_id").value = "";
	document.getElementById("frmNames").value = "";
	document.getElementById("frmSurname").value = "";
	document.getElementById("frmDocument_type").value = "";
	document.getElementById("frmDocument_number").value = "";
	document.getElementById("frmDegree_section").value = "";
	document.getElementById("frmCellphone").value = "";
	document.getElementById("frmEmail").value = "";
	document.getElementById("frmFather_document").value = "";
	document.getElementById("frmMother_document").value = "";
	document.getElementById("frmStates").value = "";
}

// Validaciones
$(document).ready(function() {
	// Validación del formulario al enviar
	$("#btnProcesar").click(function() {
		if ($("#studentForm")[0].checkValidity()) {
			// Realizar la llamada AJAX
			// ...
		} else {
			$("#studentForm")[0].classList.add('was-validated');
		}
	});
});

function validateForm() {
  var cellphone = document.getElementById('frmCellphone').value;
  var email = document.getElementById('frmEmail').value;

  var valid = true;

  if (cellphone.length !== 9 || isNaN(cellphone)) {
    document.getElementById('frmCellphone').classList.add('is-invalid');
    valid = false;
  } else {
    document.getElementById('frmCellphone').classList.remove('is-invalid');
  }

  if (email.indexOf('@') === -1 || email.indexOf('.') === -1) {
    document.getElementById('frmEmail').classList.add('is-invalid');
    valid = false;
  } else {
    document.getElementById('frmEmail').classList.remove('is-invalid');
  }

  return valid;
}